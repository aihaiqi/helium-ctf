from sage.all import EllipticCurve, Zmod, crt, randint
from Crypto.Util.number import getPrime, bytes_to_long
import os, hashlib, signal


class ECGenerator:
    def __init__(self, pbit: int=256, k: int=4):
        while True:
            p, q = [getPrime(pbit) for _ in range(2)]
            if p % 4 == 3 and q % 4 == 3:
                break
        n = p * q
        a, b = [randint(1, n-1) for _ in range(2)]
        En = EllipticCurve(Zmod(n), [a, b])

        def En_random_point():
            Ep = EllipticCurve(Zmod(p), [a, b])
            Eq = EllipticCurve(Zmod(q), [a, b])
            Gpx, Gpy = Ep.random_point().xy()
            Gqx, Gqy = Eq.random_point().xy()
            Gx = crt([int(Gpx), int(Gqx)], [p, q])
            Gy = crt([int(Gpy), int(Gqy)], [p, q])
            return En(int(Gx), int(Gy))

        self.n = n
        self.A = En_random_point()
        self.Ds = [En_random_point() for _ in range(k)]

    def __next__(self):
        out = int(self.A[0])
        ind = int(self.A[1]) % len(self.Ds)
        self.A = self.A + self.Ds[ind]
        return out

class GQProof:
    def __init__(self, n: int, e: int, y: int): # y = x^e mod n
        self.params = (n, e, y)

    def prove(self, x, r):
        n, e, y = self.params
        com = pow(r, e, n)
        chal = int(hashlib.sha256(f"{com}||{y}||{n}||{e}".encode()).hexdigest(), 16) % e
        res = r * pow(x, chal, n) % n
        return com, chal, res

    def verify(self, proof):
        try:
            n, e, y = self.params
            com, chal, res = proof

            assert 0 <= chal < e
            assert 0 < com < n and 0 < res < n
            assert pow(res, e, n) == (com * pow(y, chal, n)) % n

            return True
        except:
            return False


def proof_of_work():
    import random, string, hashlib

    ss = ''.join(random.choices(string.ascii_letters + string.digits, k=20))
    sh = hashlib.sha256(ss.encode()).hexdigest()
    print(f"sha256(XXXX + {ss[4:]}) == {sh}")
    prefix = input("XXXX>")
    return prefix == ss[:4]
assert proof_of_work()
signal.alarm(3600)

if os.path.exists("/flag"):
    FLAG = open("/flag", "r").read().strip()
else:
    FLAG = 'flag{test_flag}'


pbit = 256
k = 16
gen = ECGenerator(pbit=pbit, k=k)
n = gen.n

e = 2
x = randint(1, n-1)

MENU = '''
==========
[P]rove
[V]erify
[Q]uit
==========
'''
while True:
    try:
        print(MENU)
        inp = input(">").strip().lower()

        if inp == "q":
            raise Exception

        elif inp == "p":
            proof = GQProof(n, e, y=pow(x, e, n)).prove(x, next(gen))
            print(f"{proof = }")

        elif inp == "v":
            y = pow(bytes_to_long(FLAG.encode()), x, n)
            print(f"{y = }")

            com = int(input("com>"))
            chal = next(gen) % x
            print(f"{chal = }")
            res = int(input("res>"))
            proof = (com, chal, res)

            assert GQProof(n, x, y).verify(proof)
            print("Good job! Here is your flag:", FLAG)
            raise Exception

    except:
        print("Bye")
        exit()
