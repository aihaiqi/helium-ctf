"""Dreambound."""

import torch
import torch.nn as nn
import torch.nn.functional as F

OBS_DIM = 4
ACT_DIM = 5
H_DIM = 384


class WorldModel(nn.Module):
    def __init__(self, obs_dim=OBS_DIM, act_dim=ACT_DIM, h_dim=H_DIM):
        super().__init__()
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.h_dim = h_dim

        self.gru = nn.GRUCell(act_dim, h_dim)
        self.decoder = nn.Sequential(
            nn.Linear(h_dim, 256), nn.ReLU(),
            nn.Linear(256, obs_dim),
        )
        self.reward_head = nn.Sequential(
            nn.Linear(h_dim, 512), nn.ReLU(),
            nn.Linear(512, 512), nn.ReLU(),
            nn.Linear(512, 1),
        )
        self.continue_head = nn.Sequential(
            nn.Linear(h_dim, 128), nn.ReLU(),
            nn.Linear(128, 1),
        )

    def initial(self, batch=1, device=None):
        return torch.zeros(batch, self.h_dim, device=device)

    def step(self, h, a_onehot):
        return self.gru(a_onehot, h)

    def predict_reward(self, h):
        return self.reward_head(h).squeeze(-1)

    def decode(self, h):
        return self.decoder(h)


@torch.no_grad()
def imagine(model, actions):
    h = model.initial(actions.shape[0], actions.device)
    rewards = []
    for t in range(actions.shape[1]):
        a = F.one_hot(actions[:, t], model.act_dim).float()
        h = model.step(h, a)
        rewards.append(model.predict_reward(h))
    return torch.stack(rewards, dim=1)


def load_checkpoint(path, device="cpu"):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    model = WorldModel(**ckpt.get("config", {}))
    model.load_state_dict(ckpt["state_dict"])
    model.eval()
    return model
