"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  const canvas = $("gameCanvas");
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;
  let FLOOR = 1540;
  const GRAVITY = 1550, CORPSE_PUSH = 330, CORPSE_LIFT = 520;
  const keys = new Set();
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let round = 0, gameId = null, source = null, running = false, resetting = false, worldReady = false;
  let attempts = 5, duration = 180000, anchorMs = 0, anchorAt = performance.now();
  let finalTime = 0, displayedTime = 0, frameAt = performance.now();
  let attackFlash = 0, shake = 0, safeBusy = false, toastUntil = 0;
  let player, enemies, projectiles = [], world = {width: 1200, height: 1760, floor: FLOOR, levels: [], terrain: [], safe: {x: 600, y: 340}};
  let camera = 0, cameraY = 0, inputSeq = 0, lastDirection = 0, inputAt = 0, lastSnapshot = -1;
  let seenEvents = new Set(), doors = [], chests = [], drops = [], progressSeq = 0, doorBusy = false;

  function initWorld(data) {
    world = data.world; FLOOR = world.floor;
    player = {...data.player, cooldown: 0};
    enemies = data.enemies.map((e) => ({...e, pending: false, rotation: 0, spin: 0, launched: false}));
    projectiles = []; doors = data.doors; chests = data.chests; drops = data.drops; progressSeq = 0; doorBusy = false;
    inputSeq = 0; lastDirection = 0; inputAt = 0; lastSnapshot = -1;
    seenEvents = new Set(); camera = 0; cameraY = Math.max(0, Math.min(world.height - H, player.y - H * .72));
    attackFlash = shake = 0;
    displayedTime = 0;
    worldReady = true;
  }

  function applySnapshot(data) {
    if (data.tick_ms < lastSnapshot) return;
    lastSnapshot = data.tick_ms;
    const hp = Math.min(player.hp, data.player.hp), inventory = player.keys;
    const invulnerableUntil = Math.max(player.invulnerable_until, data.player.invulnerable_until);
    Object.assign(player, data.player, {hp, invulnerable_until: invulnerableUntil});
    if (data.seq < progressSeq) player.keys = inventory;
    applyProgress(data);
    for (const state of data.enemies) {
      const e = enemies[state.id];
      if (!e.launched && data.tick_ms >= (e.stateAt || 0)) {
        const hp = Math.min(e.hp, state.hp);
        Object.assign(e, state, {hp});
      }
    }
    projectiles = data.projectiles.map((p) => ({...p}));
    hud();
  }

  function applyProgress(data) {
    if (data.seq < progressSeq) return false;
    progressSeq = data.seq;
    player.keys = data.keys;
    doors = data.doors.map((d) => ({...d}));
    chests = data.chests.map((c) => ({...c}));
    drops = data.drops.map((d) => ({...d}));
    return true;
  }

  function receiveEvent(event) {
    if (seenEvents.has(event.seq)) return;
    seenEvents.add(event.seq);
    // HTTP attack responses can arrive before older stream events.
    if (event.tick_ms >= anchorMs) syncTime(event.tick_ms);
    if (event.type === "tick") applySnapshot(event);
    else if (event.type === "enemy_defeated") launchCorpse(event);
    else if (["key_drop", "key_collected", "door_opened", "chest_opened"].includes(event.type)) {
      if (applyProgress(event)) {
        hud();
        if (event.type === "key_collected") toast("拾取了一把钥匙");
        if (event.type === "door_opened") toast(`${event.floor}F 的门已开启`);
        if (event.type === "chest_opened") toast(`${event.floor}F 的箱子已打开`);
      }
    } else if (event.type === "player_hit") {
      player.hp = Math.min(player.hp, event.hp);
      player.invulnerable_until = Math.max(player.invulnerable_until, event.invulnerable_until);
      hud();
      if (event.hp > 0) toast(`受到攻击 · 剩余 ${event.hp} 点生命`);
    } else if (event.type === "enemy_hit") {
      const e = enemies[event.enemy_id];
      e.hp = Math.min(e.hp, event.hp);
      if (event.tick_ms >= (e.stateAt || 0)) {
        e.stateAt = event.tick_ms; e.windup_until = 0; e.shots_left = 0;
      }
    } else if (event.type === "enemy_windup") {
      const e = enemies[event.enemy_id];
      if (event.tick_ms >= (e.stateAt || 0)) {
        Object.assign(e, {stateAt: event.tick_ms, windup_until: event.until_ms, mode: event.mode,
          volley_count: event.count, windup_ms: event.windup_ms, vx: 0});
      }
    } else if (event.type === "enemy_throw") {
      const e = enemies[event.enemy_id];
      if (event.tick_ms >= (e.stateAt || 0)) {
        e.stateAt = event.tick_ms; e.windup_until = 0; e.shots_left = event.shots_left;
      }
      for (const shot of event.projectiles) {
        if (!projectiles.some((p) => p.id === shot.id)) projectiles.push({...shot});
      }
    } else if (event.type === "game_over") finish(event.reason, event.tick_ms, event);
  }

  function syncTime(ms) {
    if (!Number.isFinite(ms)) return;
    anchorMs = ms;
    anchorAt = performance.now();
  }

  function gameTime() {
    if (!running) return finalTime;
    // The browser interpolates a clock anchored by backend ticks, never wall time.
    displayedTime = Math.min(duration, Math.max(displayedTime, anchorMs + performance.now() - anchorAt));
    return displayedTime;
  }

  function connection(label, offline = false) {
    $("connection").textContent = label;
    $("connection").classList.toggle("offline", offline);
  }

  function hud() {
    const alive = enemies.filter((e) => e.alive).length;
    $("enemyStatus").innerHTML = `守卫 <b>${String(alive).padStart(2, "0")}</b> / 04`;
    $("healthStatus").innerHTML = `生命 <b>${player.hp} / 3</b> ` + [0,1,2].map((i) => `<span class="health-pip${i < player.hp ? " filled" : ""}"></span>`).join("");
    $("keyStatus").textContent = `钥匙 ×${player.keys}`;
    $("attemptStatus").innerHTML = `尝试 <b>${String(attempts).padStart(2, "0")}</b> / 05`;
  }

  function timer() {
    const left = Math.max(0, duration - gameTime());
    const secs = Math.floor(left / 1000);
    $("timeValue").innerHTML = `${String(Math.floor(secs / 60)).padStart(2, "0")}:${String(secs % 60).padStart(2, "0")}<span>.${Math.floor((left % 1000) / 100)}</span>`;
    $("timerFill").style.transform = `scaleX(${left / duration})`;
    $("timer").classList.toggle("danger", left < 10000);
  }

  function toast(message) {
    $("toast").textContent = message;
    $("toast").classList.remove("hidden");
    toastUntil = performance.now() + 2400;
  }

  async function resetGame() {
    if (resetting) return;
    resetting = true;
    const version = ++round;
    running = false;
    worldReady = false;
    finalTime = 0;
    keys.clear();
    if (source) source.close();
    source = null;
    $("safeModal").classList.add("hidden");
    $("endModal").classList.add("hidden");
    $("flagReward").classList.add("hidden");
    $("flagValue").textContent = "";
    $("toast").classList.add("hidden");
    $("resetButton").disabled = true;
    $("playAgain").disabled = true;
    $("safeSubmit").disabled = false;
    safeBusy = false;
    connection("建立新的一局…");
    try {
      const response = await fetch("/api/reset", {method: "POST"});
      if (!response.ok) throw new Error("创建游戏失败");
      const data = await response.json();
      if (version !== round) return;
      gameId = data.game_id;
      initWorld(data);
      duration = data.duration_ms;
      attempts = data.attempts_left;
      running = true;
      syncTime(data.tick_ms);
      hud();
      connect(version);
      canvas.focus({preventScroll: true});
    } catch (error) {
      connection("连接失败", true);
      showEnd("连接失败", "请确认服务正在运行，再重试。", "CONNECTION LOST");
    } finally {
      resetting = false;
      $("resetButton").disabled = false;
      $("playAgain").disabled = false;
    }
  }

  function connect(version) {
    source = new EventSource(`/api/game/${gameId}/events`);
    source.onopen = () => { if (version === round && running) connection("实时连接"); };
    source.onerror = () => { if (version === round && running) connection("重连中…", true); };
    source.addEventListener("game", (message) => {
      if (version !== round || !running) return;
      const event = JSON.parse(message.data);
      receiveEvent(event);
    });
  }

  function launchCorpse(event) {
    const e = enemies[event.enemy_id];
    if (!e || e.launched) return;
    e.alive = false;
    e.hp = 0; e.launched = true; e.windup_until = 0;
    e.x = event.x; e.y = event.y;
    e.pending = false;
    e.grounded = false;
    e.vx = event.hit_direction * CORPSE_PUSH;
    e.vy = -CORPSE_LIFT;
    e.spin = event.hit_direction * 8;
    shake = reduceMotion ? 0 : 0.18;
    hud();
    toast("守卫已击败");
  }

  function jump() {
    if (!canControl() || !player.grounded) return;
    player.vy = -630;
    player.grounded = false;
    sendInput(true);
  }

  function direction() {
    return canControl() ? Number(keys.has("KeyD") || keys.has("ArrowRight")) - Number(keys.has("KeyA") || keys.has("ArrowLeft")) : 0;
  }

  async function sendInput(jump = false) {
    if (!running || !gameId) return;
    const version = round, movement = direction();
    lastDirection = movement; inputAt = performance.now();
    try {
      const response = await fetch(`/api/game/${gameId}/input`, {
        method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({seq: ++inputSeq, direction: movement, jump}),
      });
      const data = await response.json();
      if (version !== round || !running) return;
      if (data.error === "game_ended") finish(data.reason, data.tick_ms);
    } catch (_) { if (version === round && running) connection("输入连接异常", true); }
  }

  function canControl() {
    return running && $("safeModal").classList.contains("hidden");
  }

  async function attack() {
    if (!canControl() || player.cooldown > 0) return;
    player.cooldown = 0.36;
    attackFlash = 0.16;
    const version = round;
    const center = player.x + player.facing * 50;
    const target = enemies.filter((e) => e.alive && !e.pending && Math.abs(e.x - center) < 68 && Math.abs(e.y - player.y) < 75)
      .sort((a, b) => Math.abs(a.x - center) - Math.abs(b.x - center))[0];
    if (!target) return;
    target.pending = true;
    try {
      const response = await fetch(`/api/game/${gameId}/attack/${target.id}`, {method: "POST"});
      const data = await response.json();
      if (version !== round || !running) return;
      if (!response.ok) {
        if (data.error === "game_ended") finish(data.reason, data.tick_ms);
        else if (data.error === "out_of_range") toast("目标超出范围或被障碍物遮挡");
        else if (!["attack_cooldown", "enemy_defeated"].includes(data.error)) throw new Error("攻击请求失败");
        return;
      }
      receiveEvent(data);
    } catch (_) {
      if (version === round) toast("连接异常，请再次攻击");
    } finally {
      target.pending = false;
    }
  }

  function nearSafe() { return Math.abs(player.x - world.safe.x) < 100 && Math.abs(player.y - world.safe.y) < 75; }

  function openSafe() {
    if (!running) return;
    if (!nearSafe()) { toast("先到楼顶保险箱旁"); return; }
    keys.clear();
    $("safeModal").classList.remove("hidden");
    $("safeFeedback").textContent = `剩余 ${attempts} 次尝试机会`;
    $("safeFeedback").classList.remove("error");
    $("safeCode").value = "";
    $("safeCode").focus();
  }

  function nearbyDoor() {
    return doors.find((d) => !d.opened && Math.abs(player.x-(d.x+d.w/2)) < 110 && Math.abs(player.y-d.y) <= 130);
  }

  function nearbyChest() {
    return chests.find((c) => !c.opened && Math.abs(player.x-c.x) < 75 && Math.abs(player.y-c.y) < 75);
  }

  async function interact() {
    if (!canControl()) return;
    const chest = nearbyChest(), door = nearbyDoor();
    if (!chest && !door) { openSafe(); return; }
    if (doorBusy) return;
    if (!chest && player.keys < 1) { toast("需要先拾取一把钥匙"); return; }
    const version = round;
    doorBusy = true;
    try {
      const path = chest ? `chest/${chest.floor}` : `door/${door.floor}`;
      const response = await fetch(`/api/game/${gameId}/${path}/open`, {method: "POST"});
      const data = await response.json();
      if (version !== round || !running) return;
      if (response.ok) receiveEvent(data);
      else if (data.error === "game_ended") finish(data.reason, data.tick_ms);
      else toast(data.message || "交互失败，请重试");
    } catch (_) { if (version === round) toast("连接异常，请再次尝试"); }
    finally { if (version === round) doorBusy = false; }
  }

  function closeSafe() {
    $("safeModal").classList.add("hidden");
    keys.clear();
    canvas.focus({preventScroll: true});
  }

  async function submitSafe(event) {
    event.preventDefault();
    if (!running || safeBusy) return;
    const code = $("safeCode").value;
    if (!/^[0-9a-fA-F]{16}$/.test(code)) return;
    const version = round;
    safeBusy = true;
    $("safeSubmit").disabled = true;
    try {
      const response = await fetch(`/api/game/${gameId}/safe`, {
        method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({code}),
      });
      const data = await response.json();
      if (version !== round) return;
      if (!response.ok) {
        if (data.error === "game_ended") finish(data.reason, data.tick_ms);
        else $("safeFeedback").textContent = data.message || "提交失败";
        return;
      }
      attempts = data.attempts_left;
      hud();
      syncTime(data.tick_ms);
      if (data.status !== "playing") finish(data.reason, data.tick_ms, data);
      else {
        $("safeFeedback").textContent = `密码错误 · 还剩 ${attempts} 次机会`;
        $("safeFeedback").classList.add("error");
        $("safeCode").value = "";
        $("safeCode").focus();
      }
    } catch (_) {
      if (version === round) $("safeFeedback").textContent = "连接失败，请重试";
    } finally {
      if (version === round) {
        safeBusy = false;
        $("safeSubmit").disabled = false;
      }
    }
  }

  function finish(reason, tickMs, reward = {}) {
    if (reason === "safe_opened" && (typeof reward.flag === "string" || typeof reward.flag_error === "string")) {
      $("flagValue").textContent = reward.flag ?? reward.flag_error;
      $("flagLabel").textContent = typeof reward.flag === "string" ? "FLAG" : "奖励读取失败";
      $("flagReward").classList.remove("hidden");
    }
    if (!running) return;
    if (reason === "player_killed") { player.hp = 0; hud(); }
    finalTime = tickMs ?? gameTime();
    running = false;
    shake = 0; attackFlash = 0;
    keys.clear();
    if (source) source.close();
    source = null;
    $("safeModal").classList.add("hidden");
    $("worldPrompt").classList.add("hidden");
    connection(reason === "safe_opened" ? "任务完成" : "本局结束");
    if (reason === "safe_opened") showEnd("你争取到了生机", "保险箱已开启。你在撞击前完成了任务。", "MISSION ACCOMPLISHED", true);
    else if (reason === "safe_failed") {
      attempts = 0;
      hud();
      showEnd("最后一道门，已锁死", "五次密码均不正确。本局游戏结束。", "ACCESS DENIED");
    } else if (reason === "player_killed") {
      showEnd("你被投掷物击中了", "生命值已耗尽。留意蓄力提示，利用掩体和跳跃躲避。", "VITAL SIGNAL LOST");
    } else {
      finalTime = duration;
      showEnd("最后一秒，也过去了", "流星已经抵达地表。本局游戏结束。", "IMPACT CONFIRMED");
    }
  }

  function showEnd(title, message, kicker, won = false) {
    $("endTitle").textContent = title;
    $("endMessage").textContent = message;
    $("endKicker").textContent = kicker;
    document.querySelector(".end-panel").classList.toggle("won", won);
    $("endModal").classList.remove("hidden");
    $("playAgain").focus();
  }

  function colliders() {
    return [...world.terrain, ...doors.filter((d) => !d.opened)];
  }

  function moveBody(actor, dt) {
    const oldX = actor.x, oldY = actor.y, radius = 20, height = 60;
    actor.x = Math.max(radius, Math.min(world.width - radius, actor.x + actor.vx * dt));
    for (const tile of colliders()) {
      if (!tile.solid || oldY <= tile.y || oldY - height >= tile.y + tile.h) continue;
      if (actor.x + radius > tile.x && actor.x - radius < tile.x + tile.w)
        actor.x = oldX < tile.x ? tile.x - radius : tile.x + tile.w + radius;
    }
    actor.vy += GRAVITY * dt;
    let newY = oldY + actor.vy * dt;
    actor.grounded = false;
    for (const tile of colliders()) {
      if (actor.x + radius <= tile.x || actor.x - radius >= tile.x + tile.w) continue;
      if (actor.vy >= 0 && oldY <= tile.y + .01 && newY >= tile.y) {
        newY = tile.y; actor.vy = 0; actor.grounded = true;
      } else if (tile.solid && actor.vy < 0 && oldY - height >= tile.y + tile.h && newY - height < tile.y + tile.h) {
        newY = tile.y + tile.h + height; actor.vy = 0;
      }
    }
    if (newY >= FLOOR) { newY = FLOOR; actor.vy = 0; actor.grounded = true; }
    actor.y = newY;
  }

  function physics(dt) {
    if (!running) return;
    const movement = direction();
    player.vx = movement * 285;
    if (movement) player.facing = movement;
    moveBody(player, dt);
    player.cooldown = Math.max(0, player.cooldown - dt);
    attackFlash = Math.max(0, attackFlash - dt);
    for (const e of enemies) {
      if (e.alive) {
        if (e.windup_until || e.shots_left) e.vx = 0;
        moveBody(e, dt);
      } else {
        e.vy += GRAVITY * dt; e.x += e.vx * dt; e.y += e.vy * dt;
        e.rotation += e.spin * dt;
        if (e.y >= FLOOR + 8) {
          e.y = FLOOR + 8;
          e.vy = Math.abs(e.vy) > 75 ? -Math.abs(e.vy) * .42 : 0;
          e.vx *= Math.pow(.07, dt); e.spin *= Math.pow(.04, dt);
        }
      }
    }
    for (const drop of drops) {
      if (drop.collected || drop.landed) continue;
      drop.vy += GRAVITY * dt;
      drop.x += drop.vx * dt;
      drop.y += drop.vy * dt;
      if (drop.x < 280 || drop.x > 710) {
        drop.x = Math.max(280, Math.min(710, drop.x));
        drop.vx *= -0.5;
      }
      if (drop.y >= drop.rest_y) {
        drop.y = drop.rest_y; drop.vx = 0; drop.vy = 0; drop.landed = true;
      }
    }
    for (const p of projectiles) { p.x += p.vx * dt; p.y += p.vy * dt; p.distance += p.speed * dt; }
    projectiles = projectiles.filter((p) => p.distance < 900);
    camera = Math.max(0, Math.min(world.width - W, player.x - W * .5));
    const targetY = Math.max(0, Math.min(world.height - H, player.y - H * .72));
    cameraY += (targetY - cameraY) * (1 - Math.exp(-8 * dt));
    const chest = nearbyChest(), door = nearbyDoor(), prompt = $("worldPrompt");
    prompt.classList.toggle("hidden", !(canControl() && (chest || door || nearSafe())));
    prompt.innerHTML = `<kbd>E</kbd> ${chest ? "打开箱子" : door ? `开启 ${door.floor}F 的门` : "解锁保险箱"}`;
    const promptX = chest ? chest.x : door ? door.x+door.w/2 : world.safe.x;
    const promptY = chest ? chest.y-65 : door ? door.y : world.safe.y-180;
    prompt.style.left = `${(promptX-camera) / W * 100}%`;
    prompt.style.top = `${(promptY-cameraY) / H * 100}%`;
  }

  function polygon(points, fill, stroke = null, lineWidth = 1) {
    ctx.beginPath();
    points.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
    ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lineWidth; ctx.stroke(); }
  }

  function line(x1, y1, x2, y2, color, width = 1) {
    ctx.strokeStyle = color; ctx.lineWidth = width;
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  }

  function rect(x, y, w, h, fill) { ctx.fillStyle = fill; ctx.fillRect(x, y, w, h); }
  function circle(x, y, r, fill) { ctx.fillStyle = fill; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); }
  function label(text, x, y, size, color, align = "left") {
    ctx.font = `${size}px ui-monospace, Consolas, monospace`; ctx.fillStyle = color; ctx.textAlign = align; ctx.fillText(text, x, y);
  }

  function drawSky(t) {
    const sky = ctx.createLinearGradient(0, 0, 0, FLOOR);
    sky.addColorStop(0, "#142638"); sky.addColorStop(.6, "#364954"); sky.addColorStop(1, "#ba8c6d");
    ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
    for (let i = 0; i < 82; i++) {
      const x = (i * 191 + 47) % W, y = (i * 67 + 32) % 280;
      circle(x, y, i % 7 === 0 ? 1.1 : .65, `rgba(229,225,208,${.15 + .26 * (1 + Math.sin(i + t * .0006)) / 2})`);
    }
    const haze = ctx.createRadialGradient(540, 380, 10, 540, 380, 480);
    haze.addColorStop(0, "#d19b6b44"); haze.addColorStop(1, "#d19b6b00");
    ctx.fillStyle = haze; ctx.fillRect(0, 0, W, FLOOR);
    // Long, painted cloud bands.
    polygon([[0,235],[133,223],[237,237],[371,228],[489,244],[284,252],[110,248],[0,255]], "#86949412");
    polygon([[663,181],[792,167],[966,180],[1200,165],[1200,183],[957,194],[783,187]], "#b1a49a0c");
    drawMeteor(t);
  }

  function drawMeteor(t) {
    const p = Math.min(1, t / duration);
    const ease = p * p;
    const x = 910 - 270 * ease, y = 110 + 325 * ease, r = 17 + 65 * ease;
    ctx.save();
    const glow = ctx.createRadialGradient(x, y, r * .2, x, y, r * 4);
    glow.addColorStop(0, "#ffda9c88"); glow.addColorStop(.25, "#fda16a40"); glow.addColorStop(1, "#fda16a00");
    ctx.fillStyle = glow; ctx.fillRect(x - r * 4, y - r * 4, r * 8, r * 8);
    const tail = ctx.createLinearGradient(x, y, x + 300 + 160 * p, y - 260 - 160 * p);
    tail.addColorStop(0, "#ffd39bb0"); tail.addColorStop(.3, "#f09b6650"); tail.addColorStop(1, "#eeaf7a00");
    polygon([[x-r*.7,y-r*.1],[x+380+130*p,y-400-140*p],[x+r*.75,y+r*.3]],tail);
    line(x, y, x+340, y-370, "#f5b87c55", r*.5);
    polygon([[x-r,y-r*.2],[x-r*.5,y-r*.95],[x+r*.4,y-r],[x+r,y-r*.2],[x+r*.75,y+r*.6],[x-r*.15,y+r],[x-r*.85,y+r*.5]],"#574844","#e7a366",1.5);
    polygon([[x-r,y-r*.2],[x-r*.5,y-r*.95],[x+r*.4,y-r],[x+r*.1,y-r*.18],[x-r*.5,y+r*.35]],"#ba8157");
    polygon([[x-r*.5,y-r*.95],[x+r*.4,y-r],[x+r*.1,y-r*.18]],"#e6b17b");
    circle(x+r*.3,y+r*.3,r*.2,"#3c3b3b"); circle(x-r*.3,y-r*.2,r*.13,"#5d4b42");
    for (let i = 0; i < 7; i++) {
      const phase = ((t / 1000 + i * .51) % 2.9) / 2.9;
      const sx = x + 40 + phase * 190 + i * 5;
      const sy = y - 40 - phase * 205 + Math.sin(i * 4) * 22;
      circle(sx, sy, 1 + p * 1.5, `rgba(255,195,129,${(1-phase)*.7})`);
    }
    ctx.restore();
  }

  function fillWithWindowHoles(x, y, w, h, holes, fill) {
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    for (const [hx, hy, hw, hh] of holes) ctx.rect(hx, hy, hw, hh);
    ctx.fillStyle = fill;
    ctx.fill("evenodd");
  }

  function windowHoles(levelY) {
    const holes = [];
    for (let x = 115; x < 1100; x += 150) holes.push([x + 3, levelY - 237, 80, 104]);
    return holes;
  }

  function drawBuilding(t) {
    const holesByLevel = world.levels.map(windowHoles);
    fillWithWindowHoles(60, 200, 1080, FLOOR - 200 + 100, holesByLevel.flat(), "#15232e");
    for (let i = 0; i < world.levels.length; i++) {
      const y = world.levels[i];
      fillWithWindowHoles(80, y - 280, 1040, 280, holesByLevel[i], i % 2 ? "#243540" : "#1e2e3a");
      for (let x = 115; x < 1100; x += 150) {
        rect(x + 3, y - 237, 80, 104, "#6fa2a212");
        rect(x, y - 240, 86, 3, "#101d2a");
        rect(x, y - 133, 86, 3, "#101d2a");
        rect(x, y - 237, 3, 104, "#101d2a");
        rect(x + 83, y - 237, 3, 104, "#101d2a");
        line(x + 43, y - 237, x + 43, y - 133, "#182b36", 4);
        line(x + 3, y - 182, x + 83, y - 182, "#182b36", 4);
      }
      line(100, y - 265, 1100, y - 265, "#55646a", 3);
      rect(570, y - 270, 60, 4, "#f4d399");
      label(i === 4 ? "ROOF / VAULT" : `0${i + 1}F / SECURITY`, 110, y - 85, 18, "#91a9ab");
      if (i < 4) {
        const e = enemies.find((enemy) => enemy.floor_index === i), right = i % 2 === 0;
        const door = doors.find((d) => d.floor === i+1), chest = chests.find((c) => c.floor === i+1);
        const message = door.opened ? "门已开启 · 向上攀登" : chest && !chest.opened ? "打开箱子 · 拾取钥匙 · 开门"
          : e.alive && !chest ? "击败守卫 · 拾取钥匙 · 开门" : "拾取钥匙 · 靠近楼梯门按 E";
        label(message, 600, y - 250, 12, e && e.alive ? "#e6a77d" : "#a4d9ba", "center");
        label(right ? "↑ 楼梯 →" : "← 楼梯 ↑", right ? 1015 : 165, y - 42, 13, "#bcd6c3", "center");
      }
    }
    rect(60, FLOOR, 1080, 120, "#344047");
    line(80, FLOOR, 1120, FLOOR, "#b7b18b", 4);
  }

  function drawProps(t) {
    for (const tile of colliders()) {
      const stair = tile.kind === "stair", door = tile.kind === "door";
      rect(tile.x, tile.y, tile.w, tile.h, door ? "#96574b" : stair ? "#486771" : "#4d5b60");
      rect(tile.x, tile.y, tile.w, 4, "#a3c9be");
      if (door) label(`${tile.floor}F 门 / 钥匙开启`, tile.x+tile.w/2, tile.y-14, 10, "#ffd098", "center");
      if (tile.kind === "cover" || stair || door) {
        for (let x = tile.x + 8; x < tile.x + tile.w - 10; x += 24)
          line(x, tile.y + 6, x + 9, tile.y + Math.min(tile.h - 2, 16), "#e1bd7d99", 3);
      }
    }
    for (const door of doors) if (door.opened)
      label(`${door.floor}F 门已开`, door.x+door.w/2, door.y-10, 10, "#a4d9ba", "center");
    for (const chest of chests) {
      rect(chest.x-29, chest.y-42, 58, 42, chest.opened ? "#49615a" : "#946c43");
      rect(chest.x-29, chest.y-42, 58, 8, chest.opened ? "#739b82" : "#d5a768");
      rect(chest.x-4, chest.y-32, 8, 14, "#e2c383");
      label(`${chest.floor}F 箱子${chest.opened ? " · 已开" : ""}`, chest.x, chest.y-53, 10, "#e6c996", "center");
    }
    for (const drop of drops) {
      if (drop.collected) continue;
      const y = drop.y - 7 + (drop.landed ? Math.sin(t*.004)*3 : 0);
      ctx.strokeStyle = "#ffdc87"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(drop.x-6, y, 6, 0, Math.PI*2); ctx.stroke();
      line(drop.x, y, drop.x+16, y, "#ffdc87", 4);
      line(drop.x+10, y, drop.x+10, y+6, "#ffdc87", 3);
      label("钥匙", drop.x, y-17, 10, "#ffdc87", "center");
    }
    const x = world.safe.x, y = world.safe.y;
    rect(x - 65, y - 125, 130, 125, "#3c4b4d");
    rect(x - 57, y - 117, 114, 117, "#718079");
    rect(x - 48, y - 105, 96, 100, "#263b40");
    ctx.strokeStyle = "#b7c49f"; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(x - 7, y - 55, 23, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < 3; i++) {
      const a = i * Math.PI * 2 / 3;
      line(x - 7, y - 55, x - 7 + Math.cos(a) * 18, y - 55 + Math.sin(a) * 18, "#d9c49a", 3);
    }
    rect(x + 29, y - 72, 11, 24, "#15282e");
    circle(x + 35, y - 66, 2, Math.floor(t / 800) % 2 ? "#bde6ad" : "#637c66");
    label("VAULT 04", x, y - 140, 11, "#e3d9b9", "center");
  }

  function drawProjectiles(t) {
    for (const e of enemies) {
      if (!e.alive || (!e.windup_until && !e.shots_left)) continue;
      const progress = e.windup_until ? Math.max(0, Math.min(1, 1 - (e.windup_until - t) / (e.windup_ms || 400))) : 1;
      const angle = Math.atan2(player.y - e.y, player.x - e.x);
      circle(e.x, e.y - 88, 5 + progress * 5, e.mode === "fan" ? "#ffd070" : "#ff8559");
      label(`${e.mode === "fan" ? "散射" : "连发"} ×${e.volley_count}`, e.x, e.y - 109, 10, "#ffbc87", "center");
      const half = e.mode === "fan" ? (e.volley_count - 1) * 4.5 * Math.PI / 180 : 0;
      for (const offset of half ? [-half, 0, half] : [0]) {
        line(e.x, e.y - 32, e.x + Math.cos(angle + offset) * 130,
          e.y - 32 + Math.sin(angle + offset) * 130, "#ff9b6266", 2);
      }
    }
    for (const p of projectiles) {
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(Math.atan2(p.vy, p.vx));
      line(-22, 0, -5, 0, "#ff976b88", 3);
      polygon([[-9, -3], [10, 0], [-9, 3]], "#ffe0a5", "#e58e59");
      ctx.restore();
    }
  }

  function drawPlayer(t) {
    ctx.save();ctx.translate(player.x,player.y);
    if (t < player.invulnerable_until && Math.floor(t/90)%2) ctx.globalAlpha = .4;
    // Ground shadow doesn't move up with the jump.
    ctx.fillStyle="#101b2155";ctx.beginPath();ctx.ellipse(0,3,player.grounded ? 25 : 0,5,0,0,Math.PI*2);ctx.fill();
    ctx.scale(player.facing,1);
    const stride=player.grounded&&Math.abs(player.vx)>0?Math.sin(t*.023)*5:0;
    rect(-17,-44,12,30,"#bf8352");rect(-20,-39,5,20,"#84634c");
    rect(-12,-34,28,23,"#c6c5ad");rect(-10,-44,25,21,"#e5dfc7");
    rect(-10,-47,26,9,"#e5dfc7");circle(2,-48,17,"#dddac5");
    polygon([[-10,-57],[9,-61],[18,-50],[16,-43],[-10,-44]],"#43585c");
    polygon([[-5,-55],[8,-57],[13,-51],[12,-48],[-5,-49]],"#a7d2c2");
    rect(-11,-35,7,12,"#e6a363");rect(3,-33,9,5,"#8e9890");
    rect(-10,-12,9,13+stride,"#8d9b92");rect(5,-12,9,13-stride,"#aab3a1");
    rect(-12,0+stride,12,5,"#3e5354");rect(4,0-stride,13,5,"#3e5354");
    rect(12,-28,7,15,"#cecbb5");rect(16,-17,10,7,"#405759");
    if(attackFlash>0){
      ctx.strokeStyle=`rgba(255,219,164,${attackFlash/.16})`;ctx.lineWidth=5;
      ctx.beginPath();ctx.arc(17,-28,49,-1.1,1.05);ctx.stroke();
      line(22,-17,60,-28,"#f3c28b",4);
    }
    ctx.restore();
    label("YOU",player.x,player.y-79,9,"#c0ddc7","center");
    polygon([[player.x-3,player.y-73],[player.x+3,player.y-73],[player.x,player.y-69]],"#c0ddc7");
  }

  function drawEnemy(e,t) {
    ctx.save();ctx.translate(e.x,e.y);
    ctx.fillStyle="#101b2166";ctx.beginPath();ctx.ellipse(0,3,e.grounded ? 26 : 0,5,0,0,Math.PI*2);ctx.fill();
    ctx.translate(0,-25);ctx.rotate(e.rotation);ctx.translate(0,25);
    ctx.globalAlpha=e.alive?1:.75;
    const stride=e.alive&&e.grounded&&e.vx?Math.sin(t*.03)*4:0;
    polygon([[-22,-41],[-13,-47],[15,-47],[23,-38],[18,-13],[-18,-13]],e.alive?"#8e6458":"#635e51","#b28a6b",1);
    rect(-17,-48,35,13,"#4b5350");rect(-13,-53,27,10,"#5d6860");
    rect(-12,-44,26,6,"#283b40");
    rect(-10,-43,7,3,e.alive?"#ffbd84":"#705d52");rect(5,-43,7,3,e.alive?"#ffbd84":"#705d52");
    polygon([[-11,-30],[12,-30],[8,-20],[-7,-20]],"#505b53");
    rect(-26,-34,9,17,"#a38368");rect(19,-35,8,20,"#a38368");
    rect(-15,-13,10,13+stride,"#59655b");rect(7,-13,10,13-stride,"#59655b");
    rect(-17,0+stride,14,5,"#364848");rect(5,0-stride,15,5,"#364848");
    rect(-1,-28,4,4,e.alive?"#e0ad78":"#5b5e51");
    ctx.restore();
    if(e.alive){
      label(`0${e.floor}F GUARD`,e.x,e.y-71,8,"#c6b5a0","center");
      for(let hp=0;hp<3;hp++) rect(e.x-19+hp*14,e.y-65,10,4,hp<e.hp?"#e9a578":"#3f4e51");
    }
  }

  function render() {
    const t=gameTime();
    ctx.save();
    if(shake>0&&!reduceMotion)ctx.translate(Math.sin(performance.now()*.08)*shake*18,Math.cos(performance.now()*.1)*shake*10);
    drawSky(t);
    if(worldReady){
      ctx.save(); ctx.translate(-camera, -cameraY);
      drawBuilding(t);drawProps(t);enemies.forEach((e)=>drawEnemy(e,t));drawPlayer(t);drawProjectiles(t);
      ctx.restore();
      rect(W-25, 170, 3, H-240, "#ffffff22");
      const mapY = (y) => 170 + (H-240) * y / world.height;
      rect(W-28, mapY(player.y), 9, 5, "#bce4c8");
      for(const e of enemies) if(e.alive) rect(W-27, mapY(e.home_y), 7, 3, "#e9a578");
      rect(W-28, mapY(world.safe.y), 9, 5, "#f4b16b");
    }
    if(t>duration-2000){ctx.fillStyle=`rgba(255,195,130,${Math.min(.7,(t-(duration-2000))/2000*.7)})`;ctx.fillRect(0,0,W,H);}
    ctx.restore();
  }

  function frame(now) {
    const dt=Math.min(.05,Math.max(0,(now-frameAt)/1000));frameAt=now;
    // Visual effects must expire even after gameplay stops.
    shake = Math.max(0, shake - dt);
    // Predict motion between authoritative server snapshots.
    let remaining=dt;while(remaining>0){const step=Math.min(remaining,1/120);physics(step);remaining-=step;}
    if(toastUntil&&now>toastUntil){$("toast").classList.add("hidden");toastUntil=0;}
    if(running && (direction() !== lastDirection || now-inputAt >= 200)) sendInput();
    timer();render();requestAnimationFrame(frame);
  }

  window.addEventListener("keydown",(event)=>{
    const typing=event.target instanceof HTMLInputElement;
    if(event.code==="Escape"){
      if(!$("safeModal").classList.contains("hidden"))closeSafe();
      return;
    }
    if(typing)return;
    if(["ArrowLeft","ArrowRight","ArrowUp","Space"].includes(event.code))event.preventDefault();
    keys.add(event.code);
    if(event.repeat)return;
    if(["KeyW","ArrowUp"].includes(event.code))jump();
    else if(["KeyJ","Space"].includes(event.code))attack();
    else if(event.code==="KeyE"){event.preventDefault();interact();}
    else if(event.code==="KeyR")resetGame();
  });

  window.addEventListener("keyup",(event)=>keys.delete(event.code));
  window.addEventListener("blur",()=>keys.clear());
  document.addEventListener("visibilitychange",()=>keys.clear());
  document.querySelectorAll("[data-control]").forEach((button)=>{
    const control=button.dataset.control;
    const release=()=>{if(control==="left")keys.delete("ArrowLeft");if(control==="right")keys.delete("ArrowRight");};
    button.addEventListener("pointerdown",(event)=>{
      event.preventDefault();button.setPointerCapture(event.pointerId);
      if(control==="left")keys.add("ArrowLeft");else if(control==="right")keys.add("ArrowRight");
      else if(control==="jump")jump();else if(control==="attack")attack();else interact();
    });
    button.addEventListener("pointerup",release);button.addEventListener("pointercancel",release);button.addEventListener("lostpointercapture",release);
  });
  $("resetButton").addEventListener("click",resetGame);
  $("playAgain").addEventListener("click",resetGame);
  $("closeSafe").addEventListener("click",closeSafe);
  $("safeForm").addEventListener("submit",submitSafe);
  $("safeCode").addEventListener("input",()=>{$("safeCode").value=$("safeCode").value.replace(/[^0-9a-f]/gi,"").slice(0,16).toUpperCase();});
  $("safeModal").addEventListener("click",(event)=>{if(event.target===$("safeModal"))closeSafe();});
  // Keep keyboard focus in the currently open dialog.
  document.addEventListener("keydown",(event)=>{
    if(event.key!=="Tab")return;
    const modal=!$("safeModal").classList.contains("hidden")?$("safeModal"):!$("endModal").classList.contains("hidden")?$("endModal"):null;
    if(!modal)return;
    const buttons=[...modal.querySelectorAll("button:not(:disabled),input:not(:disabled)")];
    const first=buttons[0],last=buttons[buttons.length-1];
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
  });
  window.addEventListener("pagehide",()=>{if(source)source.close();});
  requestAnimationFrame(frame);resetGame();
})();
