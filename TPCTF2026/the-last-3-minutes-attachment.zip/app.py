from __future__ import annotations

import json
import math
import random
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from flask import Flask, Response, jsonify, render_template, request, stream_with_context

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 4096

DURATION_MS = 180_000
TICK_MS = 200
STEP_MS = 20
MAX_ATTEMPTS = 5
PLAYER_MAX_HP = 3
HURT_INVULNERABILITY_MS = 800
WORLD_WIDTH = 1200
WORLD_HEIGHT = 1760
FLOOR = 1540
FLOOR_LEVELS = [1540, 1240, 940, 640, 340]
GRAVITY = 1550
PLAYER_SPEED = 285
JUMP_SPEED = 630
ATTACK_COOLDOWN_MS = 320
THROW_RANGE = 800
THROW_COOLDOWN_MS = 1400
WINDUP_MS = 700
BURST_INTERVAL_MS = 160
PROJECTILE_SPEED = 560
PROJECTILE_RANGE = 900
DROP_SPEED_MIN = 180
DROP_SPEED_SPAN = 180
CHEST_SPEED_MIN = 240
CHEST_SPEED_SPAN = 240
DROP_LEFT = 280
DROP_RIGHT = 710
ACTIONS = {0: "jump", 1: "move_left", 2: "move_right"}
# Four guarded floors. Solid slabs force ascent through alternating stairwells.
TERRAIN = [
    {"x": 60, "y": 200, "w": 20, "h": 1340, "solid": True, "kind": "wall"},
    {"x": 1120, "y": 200, "w": 20, "h": 1340, "solid": True, "kind": "wall"},
]
for level in range(4):
    y = FLOOR_LEVELS[level]
    right = level % 2 == 0
    TERRAIN.extend([
        {"x": 80 if right else 250, "y": y - 300, "w": 870, "h": 20, "solid": True, "kind": "floor"},
        {"x": 850 if right else 235, "y": y - 100, "w": 115, "h": 14, "solid": False, "kind": "stair"},
        {"x": 970 if right else 100, "y": y - 200, "w": 130, "h": 14, "solid": False, "kind": "stair"},
        {"x": 410 if right else 730, "y": y - 65, "w": 65, "h": 65, "solid": True, "kind": "cover"},
    ])
DOORS = [dict(x=950 if level % 2 == 0 else 80, y=FLOOR_LEVELS[level]-300, w=170, h=20,
              solid=True, kind="door", floor=level+1, opened=False) for level in range(4)]
CHESTS = [dict(floor=level+1, x=330, y=FLOOR_LEVELS[level], opened=False) for level in (0, 2)]
SAFE = {"x": 600, "y": 340}


def body(x: float, y: float = FLOOR) -> dict:
    return dict(x=x, y=y, vx=0.0, vy=0.0, facing=1, grounded=True)


def move_body(actor: dict, dt: float, terrain=None):
    terrain = TERRAIN if terrain is None else terrain
    radius, height = 20, 60
    old_x, old_y = actor["x"], actor["y"]
    actor["x"] = max(radius, min(WORLD_WIDTH - radius, old_x + actor["vx"] * dt))
    for tile in terrain:
        if not tile["solid"] or old_y <= tile["y"] or old_y - height >= tile["y"] + tile["h"]:
            continue
        if actor["x"] + radius > tile["x"] and actor["x"] - radius < tile["x"] + tile["w"]:
            actor["x"] = tile["x"] - radius if old_x < tile["x"] else tile["x"] + tile["w"] + radius
    actor["vy"] += GRAVITY * dt
    new_y = old_y + actor["vy"] * dt
    actor["grounded"] = False
    for tile in terrain:
        if actor["x"] + radius <= tile["x"] or actor["x"] - radius >= tile["x"] + tile["w"]:
            continue
        if actor["vy"] >= 0 and old_y <= tile["y"] + .01 and new_y >= tile["y"]:
            new_y, actor["vy"], actor["grounded"] = tile["y"], 0.0, True
        elif tile["solid"] and actor["vy"] < 0 and old_y - height >= tile["y"] + tile["h"] and new_y - height < tile["y"] + tile["h"]:
            new_y, actor["vy"] = tile["y"] + tile["h"] + height, 0.0
    if new_y >= FLOOR:
        new_y, actor["vy"], actor["grounded"] = FLOOR, 0.0, True
    actor["y"] = new_y


def segment_box(x1, y1, x2, y2, left, top, right, bottom) -> bool:
    """Swept collision, including endpoints and parallel segments."""
    low, high = 0.0, 1.0
    for origin, delta, minimum, maximum in ((x1, x2 - x1, left, right), (y1, y2 - y1, top, bottom)):
        if abs(delta) < 1e-10:
            if not minimum <= origin <= maximum:
                return False
        else:
            a, b = (minimum - origin) / delta, (maximum - origin) / delta
            low, high = max(low, min(a, b)), min(high, max(a, b))
            if low > high:
                return False
    return True


def blocked(x1, y1, x2, y2, padding=0, terrain=None) -> bool:
    return any(segment_box(x1, y1, x2, y2, t["x"] - padding, t["y"] - padding,
                           t["x"] + t["w"] + padding, t["y"] + t["h"] + padding)
               for t in (TERRAIN if terrain is None else terrain))


@dataclass
class Game:
    rng: random.Random = field(default_factory=random.Random, repr=False)
    game_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    started_at: float = field(default_factory=time.monotonic)
    password: int = field(init=False, repr=False)
    player: dict = field(default_factory=lambda: body(180))
    enemies: list[dict] = field(init=False)
    projectiles: list[dict] = field(default_factory=list)
    doors: list[dict] = field(default_factory=lambda: [d.copy() for d in DOORS])
    chests: list[dict] = field(default_factory=lambda: [c.copy() for c in CHESTS])
    drops: list[dict] = field(default_factory=list)
    door_events: dict[int, dict] = field(default_factory=dict, repr=False)
    chest_events: dict[int, dict] = field(default_factory=dict, repr=False)
    next_projectile: int = 1
    simulated_ms: int = 0
    input_until: int = 0
    input_seq: int = -1
    attack_ready: int = 0
    attempts: int = 0
    status: str = "playing"
    reason: str | None = None
    ended_at_ms: int | None = None
    events: list[dict] = field(default_factory=list, repr=False)
    lock: threading.RLock = field(default_factory=threading.RLock, repr=False)

    def __post_init__(self):
        self.password = self.rng.getrandbits(64)
        self.player.update(hp=PLAYER_MAX_HP, max_hp=PLAYER_MAX_HP, invulnerable_until=0, keys=0)
        self.enemies = [dict(body(550, FLOOR_LEVELS[level]), id=i, floor=level+1, floor_index=level,
                             hp=3, alive=True, home_y=FLOOR_LEVELS[level], patrol_direction=1,
                             windup_until=0, throw_ready=1000, action="idle", mode=None,
                             volley_count=0, shots_left=0, next_shot=0)
                        for i, level in enumerate(range(4))]

    def terrain(self) -> list[dict]:
        return TERRAIN + [d for d in self.doors if not d["opened"]]

    def progress(self) -> dict:
        return {"keys": self.player["keys"], "doors": [d.copy() for d in self.doors],
                "chests": [c.copy() for c in self.chests], "drops": [d.copy() for d in self.drops]}

    def collect_keys(self, tick_ms: int):
        for drop in self.drops:
            if (drop["landed"] and not drop["collected"] and abs(self.player["x"]-drop["x"]) < 42
                    and abs(self.player["y"]-drop["y"]) < 70
                    and not blocked(self.player["x"], self.player["y"]-32, drop["x"], drop["y"], terrain=self.terrain())):
                drop["collected"] = True
                self.player["keys"] += 1
                self.emit("key_collected", tick_ms, drop_id=drop["id"], **self.progress())

    def spawn_key(self, source: str, source_id: int, x: float, y: float,
                  rest_y: float, vx: float, vy: float, tick_ms: int):
        drop_id = f"{source}-{source_id}"
        self.drops.append(dict(id=drop_id, x=x, y=y, vx=vx, vy=vy,
                               rest_y=rest_y, landed=False, collected=False))
        self.emit("key_drop", tick_ms, source=source, source_id=source_id, **self.progress())

    def move_drops(self):
        dt = STEP_MS / 1000
        for drop in self.drops:
            if drop["collected"] or drop["landed"]:
                continue
            drop["vy"] += GRAVITY * dt
            drop["x"] += drop["vx"] * dt
            drop["y"] += drop["vy"] * dt
            if drop["x"] < DROP_LEFT or drop["x"] > DROP_RIGHT:
                drop["x"] = max(DROP_LEFT, min(DROP_RIGHT, drop["x"]))
                drop["vx"] *= -0.5
            if drop["y"] >= drop["rest_y"]:
                drop.update(y=drop["rest_y"], vx=0.0, vy=0.0, landed=True)

    def visible_target(self, enemy: dict) -> bool:
        return (math.hypot(self.player["x"] - enemy["x"], self.player["y"] - enemy["y"]) <= THROW_RANGE
                and not blocked(enemy["x"], enemy["y"] - 32, self.player["x"], self.player["y"] - 32,
                                terrain=self.terrain()))

    def patrol(self, enemy: dict):
        # Keep each sentry on its assigned floor, away from stairwell edges.
        if enemy["windup_until"] or enemy["shots_left"]:
            enemy["vx"] = 0
            return
        left, right = (530, 800) if enemy["floor_index"] % 2 == 0 else (400, 670)
        if enemy["x"] <= left:
            enemy["patrol_direction"] = 1
        elif enemy["x"] >= right:
            enemy["patrol_direction"] = -1
        direction = enemy["patrol_direction"]
        if enemy["action"] == "move_left":
            direction = -1
        elif enemy["action"] == "move_right":
            direction = 1
        if enemy["x"] <= left and direction < 0 or enemy["x"] >= right and direction > 0:
            direction *= -1
        enemy["vx"] = direction * (90 + enemy["floor_index"] * 10)
        enemy["facing"] = direction

    def elapsed_ms(self, now: float | None = None) -> int:
        if self.ended_at_ms is not None:
            return self.ended_at_ms
        return max(0, min(DURATION_MS, int(((time.monotonic() if now is None else now) - self.started_at) * 1000)))

    def emit(self, kind: str, tick_ms: int, **payload) -> dict:
        event = {"seq": len(self.events) + 1, "type": kind, "tick_ms": tick_ms, **payload}
        self.events.append(event)
        return event

    def finish(self, reason: str, tick_ms: int, **payload) -> dict:
        self.status = "won" if reason == "safe_opened" else "ended"
        self.reason, self.ended_at_ms = reason, tick_ms
        return self.emit("game_over", tick_ms, status=self.status, reason=reason, **payload)

    def snapshot(self) -> dict:
        return {"player": self.player.copy(), "enemies": [e.copy() for e in self.enemies],
                "projectiles": [p.copy() for p in self.projectiles], **self.progress()}

    def enemy_tick(self, tick_ms: int):
        commands = []
        for enemy in self.enemies:
            if not enemy["alive"]:
                continue
            action = ACTIONS.get(self.rng.getrandbits(6), "idle")
            enemy["action"] = action
            if action == "jump" and enemy["grounded"] and not enemy["windup_until"] and not enemy["shots_left"]:
                enemy["vy"], enemy["grounded"] = -360, False
            self.patrol(enemy)
            commands.append({"enemy_id": enemy["id"], "action": action})
        self.emit("tick", tick_ms, actions=commands, **self.snapshot())

    def update_combat(self, tick_ms: int):
        for enemy in self.enemies:
            if not enemy["alive"]:
                continue
            if enemy["windup_until"] and tick_ms >= enemy["windup_until"]:
                enemy["windup_until"] = 0
                enemy["next_shot"] = tick_ms
            if enemy["shots_left"] and not enemy["windup_until"] and tick_ms >= enemy["next_shot"]:
                spread = (self.rng.getrandbits(5) - 15.5) * math.radians(12 / 31)
                origin_x, origin_y = enemy["x"], enemy["y"] - 32
                aim = math.atan2(self.player["y"] - 32 - origin_y, self.player["x"] - origin_x)
                speed = PROJECTILE_SPEED + enemy["floor_index"] * 30
                released = self.visible_target(enemy)
                count = enemy["volley_count"] if enemy["mode"] == "fan" else 1
                offsets = [(i - (count - 1) / 2) * math.radians(9) for i in range(count)]
                projectiles = []
                if released:
                    for offset in offsets:
                        angle = aim + spread + offset
                        projectile = dict(id=self.next_projectile, enemy_id=enemy["id"], x=origin_x, y=origin_y,
                                          vx=math.cos(angle) * speed, vy=math.sin(angle) * speed,
                                          speed=speed, distance=0.0)
                        self.next_projectile += 1
                        self.projectiles.append(projectile)
                        projectiles.append(projectile.copy())
                enemy["shots_left"] -= 1
                enemy["next_shot"] = tick_ms + BURST_INTERVAL_MS
                enemy["facing"] = 1 if self.player["x"] >= enemy["x"] else -1
                self.emit("enemy_throw", tick_ms, enemy_id=enemy["id"], released=released,
                          mode=enemy["mode"], shots_left=enemy["shots_left"], projectiles=projectiles)
                if not enemy["shots_left"]:
                    enemy["throw_ready"] = tick_ms + THROW_COOLDOWN_MS - enemy["floor_index"] * 60
            elif not enemy["windup_until"] and not enemy["shots_left"] and tick_ms >= enemy["throw_ready"] and self.visible_target(enemy):
                pattern = self.rng.getrandbits(6)
                enemy["mode"] = "fan" if pattern & 1 else "burst"
                enemy["volley_count"] = 2 + ((pattern >> 1) & 3)
                enemy["shots_left"] = 1 if enemy["mode"] == "fan" else enemy["volley_count"]
                enemy["windup_until"] = tick_ms + WINDUP_MS - enemy["floor_index"] * 20
                enemy["vx"] = 0
                self.emit("enemy_windup", tick_ms, enemy_id=enemy["id"], until_ms=enemy["windup_until"],
                          mode=enemy["mode"], count=enemy["volley_count"], windup_ms=WINDUP_MS - enemy["floor_index"] * 20)

    def step(self, tick_ms: int):
        dt = STEP_MS / 1000
        if tick_ms >= self.input_until:
            self.player["vx"] = 0
        move_body(self.player, dt, self.terrain())
        for enemy in self.enemies:
            if enemy["alive"]:
                self.patrol(enemy)
                move_body(enemy, dt, self.terrain())
        self.move_drops()
        self.collect_keys(tick_ms)
        survivors = []
        for projectile in self.projectiles:
            x, y = projectile["x"], projectile["y"]
            remaining = PROJECTILE_RANGE - projectile["distance"]
            speed = projectile["speed"]
            travel = min(speed * dt, remaining)
            nx, ny = x + projectile["vx"] * travel / speed, y + projectile["vy"] * travel / speed
            if blocked(x, y, nx, ny, 4, terrain=self.terrain()) or ny >= FLOOR or nx < 0 or nx > WORLD_WIDTH:
                continue
            p = self.player
            if segment_box(x, y, nx, ny, p["x"] - 21, p["y"] - 61, p["x"] + 21, p["y"] + 3):
                if tick_ms >= p["invulnerable_until"]:
                    p["hp"] -= 1
                    p["invulnerable_until"] = tick_ms + HURT_INVULNERABILITY_MS
                    self.emit("player_hit", tick_ms, hp=p["hp"], invulnerable_until=p["invulnerable_until"],
                              enemy_id=projectile["enemy_id"])
                    if p["hp"] == 0:
                        self.finish("player_killed", tick_ms, hp=0, enemy_id=projectile["enemy_id"])
                        return
                continue
            projectile.update(x=nx, y=ny, distance=projectile["distance"] + travel)
            if projectile["distance"] < PROJECTILE_RANGE:
                survivors.append(projectile)
        self.projectiles = survivors
        self.update_combat(tick_ms)
        if tick_ms % TICK_MS == 0:
            self.enemy_tick(tick_ms)

    def advance(self, now: float | None = None):
        if self.status != "playing":
            return
        elapsed = self.elapsed_ms(now)
        while self.simulated_ms + STEP_MS <= elapsed and self.simulated_ms + STEP_MS < DURATION_MS:
            self.simulated_ms += STEP_MS
            self.step(self.simulated_ms)
            if self.status != "playing":
                return
        if elapsed >= DURATION_MS:
            self.finish("timeout", DURATION_MS)

    def public_state(self) -> dict:
        return {"game_id": self.game_id, "tick_ms": self.elapsed_ms(), "duration_ms": DURATION_MS,
                "enemy_tick_ms": TICK_MS, "attempts_left": MAX_ATTEMPTS - self.attempts,
                "status": self.status, "reason": self.reason, **self.snapshot()}


games: dict[str, Game] = {}
games_lock = threading.RLock()


def get_game(game_id: str) -> Game | None:
    with games_lock:
        return games.get(game_id)


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/reset")
def reset():
    game = Game()
    with games_lock:
        cutoff = time.monotonic() - 300
        for old_id in [key for key, value in games.items() if value.started_at < cutoff]:
            games.pop(old_id)
        games[game.game_id] = game
    return jsonify(**game.public_state(), world={"width": WORLD_WIDTH, "height": WORLD_HEIGHT, "floor": FLOOR, "levels": FLOOR_LEVELS, "terrain": TERRAIN, "safe": SAFE}), 201


@app.get("/api/game/<game_id>")
def state(game_id: str):
    game = get_game(game_id)
    if game is None:
        return jsonify(error="game_not_found"), 404
    with game.lock:
        game.advance()
        return jsonify(game.public_state())


@app.get("/api/game/<game_id>/events")
def events(game_id: str):
    game = get_game(game_id)
    if game is None:
        return jsonify(error="game_not_found"), 404
    try:
        cursor = max(0, int(request.headers.get("Last-Event-ID", "0")))
    except ValueError:
        cursor = 0

    @stream_with_context
    def generate():
        nonlocal cursor
        yield "retry: 1000\n\n"
        while True:
            with game.lock:
                game.advance()
                batch = game.events[cursor:]
                terminal = game.status != "playing"
            for event in batch:
                cursor = event["seq"]
                yield f"id: {cursor}\nevent: game\ndata: {json.dumps(event, separators=(',', ':'))}\n\n"
            if terminal:
                return
            time.sleep(0.02)

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no"})


@app.post("/api/game/<game_id>/input")
def player_input(game_id: str):
    game = get_game(game_id)
    if game is None:
        return jsonify(error="game_not_found"), 404
    data = request.get_json(silent=True)
    if not isinstance(data, dict) or type(data.get("direction")) is not int or type(data.get("seq")) is not int or type(data.get("jump", False)) is not bool:
        return jsonify(error="invalid_input"), 400
    with game.lock:
        game.advance()
        if game.status != "playing":
            return jsonify(error="game_ended", **game.public_state()), 409
        if data["seq"] > game.input_seq:
            game.input_seq = data["seq"]
            game.player["vx"] = data["direction"] * PLAYER_SPEED
            if data["direction"]:
                game.player["facing"] = data["direction"]
            if data.get("jump") and game.player["grounded"]:
                game.player["vy"] = -JUMP_SPEED
            game.input_until = game.simulated_ms + 800
        return jsonify(tick_ms=game.elapsed_ms(), player=game.player.copy(), input_seq=game.input_seq)


@app.post("/api/game/<game_id>/attack/<int:enemy_id>")
def attack(game_id: str, enemy_id: int):
    game = get_game(game_id)
    if game is None:
        return jsonify(error="game_not_found"), 404
    if not 0 <= enemy_id < len(game.enemies):
        return jsonify(error="enemy_not_found"), 404
    with game.lock:
        game.advance()
        if game.status != "playing":
            return jsonify(error="game_ended", **game.public_state()), 409
        enemy, player = game.enemies[enemy_id], game.player
        if not enemy["alive"]:
            return jsonify(error="enemy_defeated"), 409
        now = game.elapsed_ms()
        if now < game.attack_ready:
            return jsonify(error="attack_cooldown"), 429
        game.attack_ready = now + ATTACK_COOLDOWN_MS
        forward = (enemy["x"] - player["x"]) * player["facing"]
        if not (-10 <= forward <= 115 and abs(enemy["y"] - player["y"]) < 75) or blocked(player["x"], player["y"] - 32, enemy["x"], enemy["y"] - 32, terrain=game.terrain()):
            return jsonify(error="out_of_range"), 403
        enemy["hp"] -= 1
        enemy["windup_until"], enemy["shots_left"] = 0, 0
        enemy["throw_ready"] = now + 260
        if enemy["hp"]:
            return jsonify(game.emit("enemy_hit", now, enemy_id=enemy_id, hp=enemy["hp"], interrupted=True))
        enemy["alive"], enemy["windup_until"], enemy["vx"] = False, 0, 0
        defeated = game.emit("enemy_defeated", now, enemy_id=enemy_id, hp=0, x=enemy["x"], y=enemy["y"],
                             hit_direction=player["facing"])
        if enemy["floor"] in (2, 4):
            theta = game.rng.getrandbits(32)
            speed = DROP_SPEED_MIN + game.rng.getrandbits(16) * DROP_SPEED_SPAN / 65535
            game.spawn_key("guard", enemy_id, enemy["x"], enemy["y"]-42,
                           enemy["home_y"]-18, math.cos(theta)*speed,
                           -abs(math.sin(theta))*speed, now)
        return jsonify(defeated)


@app.post("/api/game/<game_id>/chest/<int:floor>/open")
def open_chest(game_id: str, floor: int):
    game = get_game(game_id)
    if game is None:
        return jsonify(error="game_not_found"), 404
    with game.lock:
        game.advance()
        if game.status != "playing":
            return jsonify(error="game_ended", **game.public_state()), 409
        chest = next((c for c in game.chests if c["floor"] == floor), None)
        if chest is None:
            return jsonify(error="chest_not_found"), 404
        if chest["opened"]:
            return jsonify(game.chest_events[floor])
        if (abs(game.player["x"] - chest["x"]) >= 75 or abs(game.player["y"] - chest["y"]) >= 75
                or blocked(game.player["x"], game.player["y"]-32, chest["x"], chest["y"]-32,
                           terrain=game.terrain())):
            return jsonify(error="out_of_range", message="请先靠近箱子"), 403
        chest["opened"] = True
        now = game.elapsed_ms()
        opened = game.emit("chest_opened", now, floor=floor, **game.progress())
        game.chest_events[floor] = opened
        speed = CHEST_SPEED_MIN + game.rng.getrandbits(16) * CHEST_SPEED_SPAN / 65535
        game.spawn_key("chest", floor, chest["x"], chest["y"]-44,
                       chest["y"]-18, 0.0, -speed, now)
        return jsonify(opened)


@app.post("/api/game/<game_id>/door/<int:floor>/open")
def open_door(game_id: str, floor: int):
    game = get_game(game_id)
    if game is None:
        return jsonify(error="game_not_found"), 404
    with game.lock:
        game.advance()
        if game.status != "playing":
            return jsonify(error="game_ended", **game.public_state()), 409
        door = next((d for d in game.doors if d["floor"] == floor), None)
        if door is None:
            return jsonify(error="door_not_found"), 404
        if door["opened"]:
            return jsonify(game.door_events[floor])
        if abs(game.player["x"]-(door["x"]+door["w"]/2)) >= 110 or abs(game.player["y"]-door["y"]) > 130:
            return jsonify(error="out_of_range", message="请先靠近对应楼层的门"), 403
        if game.player["keys"] < 1:
            return jsonify(error="key_required", message="需要先拾取一把钥匙"), 403
        game.player["keys"] -= 1
        door["opened"] = True
        event = game.emit("door_opened", game.elapsed_ms(), floor=floor, **game.progress())
        game.door_events[floor] = event
        return jsonify(event)


@app.post("/api/game/<game_id>/safe")
def safe(game_id: str):
    game = get_game(game_id)
    if game is None:
        return jsonify(error="game_not_found"), 404
    data = request.get_json(silent=True)
    code = data.get("code") if isinstance(data, dict) else None
    if not isinstance(code, str) or not re.fullmatch(r"[0-9a-fA-F]{16}", code):
        return jsonify(error="invalid_code", message="请输入 16 位十六进制密码"), 400
    with game.lock:
        game.advance()
        if game.status != "playing":
            return jsonify(error="game_ended", **game.public_state()), 409
        if abs(game.player["x"] - SAFE["x"]) >= 100 or abs(game.player["y"] - SAFE["y"]) >= 75:
            return jsonify(error="safe_out_of_range", message="请先到达楼顶保险箱旁"), 403
        if any(not door["opened"] for door in game.doors):
            return jsonify(error="doors_locked", message="请先用钥匙开启四层的门"), 403
        game.attempts += 1
        correct = int(code, 16) == game.password
        reward = {}
        if correct:
            try:
                reward["flag"] = (Path.cwd() / "flag.txt").read_text(encoding="utf-8")
            except (OSError, UnicodeError):
                reward["flag_error"] = "无法读取 flag.txt，请确认文件存在且为 UTF-8 编码。"
            game.finish("safe_opened", game.elapsed_ms(), **reward)
        elif game.attempts == MAX_ATTEMPTS:
            game.finish("safe_failed", game.elapsed_ms())
        return jsonify(correct=correct, **game.public_state(), **reward)


@app.get("/healthz")
def healthz():
    return "ok", 200, {"Content-Type": "text/plain"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)