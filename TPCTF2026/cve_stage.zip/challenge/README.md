# AsterOps white-box challenge

Extract `challenge.zip`, enter the `challenge/` directory, and run:

```sh
docker compose up --build -d
```

Open `http://127.0.0.1:8080/`. The local flags and stage tokens are generated
for debugging only and are not competition answers. Start with Provider Relay;
each later panel unlocks with the secret recovered from the previous stage.

Stop and remove the local environment with:

```sh
docker compose down -v
```
