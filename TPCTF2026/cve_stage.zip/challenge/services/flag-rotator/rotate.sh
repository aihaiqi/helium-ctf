#!/bin/sh
set -eu

: "${ANSWER_FLAG1:?missing ANSWER_FLAG1}"
: "${ANSWER_FLAG2:?missing ANSWER_FLAG2}"
: "${ANSWER_FLAG3:?missing ANSWER_FLAG3}"
: "${ANSWER_FLAG4:?missing ANSWER_FLAG4}"

token() {
    value="$(od -An -N32 -tx1 /dev/urandom | tr -d ' \n')"
    test "${#value}" -eq 64
    printf '%s' "$value"
}

php_token="$(token)"
node_token="$(token)"
go_token="$(token)"

umask 022
printf '%s' "$ANSWER_FLAG1" > /out/flag1/value
printf '%s' "$ANSWER_FLAG2" > /out/flag2/value
printf '%s' "$ANSWER_FLAG3" > /out/flag3/value
printf '%s' "$ANSWER_FLAG4" > /out/flag4/value
printf '%s' "$php_token" > /out/gate-php/token
printf '%s' "$node_token" > /out/gate-node/token
printf '%s' "$go_token" > /out/gate-go/token

chmod 0444 \
    /out/flag1/value /out/flag2/value /out/flag3/value /out/flag4/value \
    /out/gate-php/token /out/gate-node/token /out/gate-go/token
