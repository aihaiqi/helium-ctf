"""Provider relay service for the first stage."""

from __future__ import annotations

import importlib.metadata
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit


EXPECTED_VERSION = os.environ.get("EXPECTED_LITELLM_VERSION", "1.106.2")
ACTUAL_VERSION = importlib.metadata.version("litellm")
if ACTUAL_VERSION != EXPECTED_VERSION:
    raise SystemExit(
        f"LiteLLM version mismatch: expected {EXPECTED_VERSION}, got {ACTUAL_VERSION}"
    )

RUNTIME_PYTHON = Path("/runtime/venv/bin/python")
RUNTIME_SITE = Path(
    subprocess.check_output(
        [
            str(RUNTIME_PYTHON),
            "-c",
            "import sysconfig; print(sysconfig.get_paths()['purelib'])",
        ],
        text=True,
        timeout=10,
    ).strip()
)
UPLOAD_DIR = Path("/runtime/uploads")
EVIDENCE_FILE = Path("/runtime/evidence/proof.json")
WORKER_LOG = Path("/runtime/worker.log")
UI_ROOT = Path("/app/ui")
MAX_WHEEL_BYTES = 1_048_576
INSTALL_LOCK = threading.Lock()

_worker: subprocess.Popen[str] | None = None
_worker_log_handle = None


def _stop_worker() -> None:
    global _worker, _worker_log_handle
    if _worker is not None and _worker.poll() is None:
        _worker.terminate()
        try:
            _worker.wait(timeout=3)
        except subprocess.TimeoutExpired:
            _worker.kill()
            try:
                _worker.wait(timeout=3)
            except subprocess.TimeoutExpired:
                pass
    _worker = None
    if _worker_log_handle is not None:
        _worker_log_handle.close()
        _worker_log_handle = None


def _start_worker() -> None:
    global _worker, _worker_log_handle
    WORKER_LOG.write_text("", encoding="utf-8")
    _worker_log_handle = WORKER_LOG.open("a", encoding="utf-8")
    _worker = subprocess.Popen(
        [str(RUNTIME_PYTHON), "/app/worker_daemon.py"],
        stdin=subprocess.DEVNULL,
        stdout=_worker_log_handle,
        stderr=subprocess.STDOUT,
        text=True,
        env={**os.environ, "PYTHONUNBUFFERED": "1"},
    )


def _restart_worker() -> None:
    _stop_worker()
    _start_worker()


def _json_bytes(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


class Handler(BaseHTTPRequestHandler):
    server_version = "AsterOps-ProviderRelay/1"

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"http {self.address_string()} {fmt % args}", flush=True)

    def _headers(self, content_type: str, length: int) -> None:
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'")

    def _send_json(self, status: int, value: object) -> None:
        body = _json_bytes(value)
        self.send_response(status)
        self._headers("application/json; charset=utf-8", len(body))
        self.end_headers()
        self.wfile.write(body)

    def _send_static(self, name: str, content_type: str) -> None:
        try:
            body = (UI_ROOT / name).read_bytes()
        except OSError:
            self._send_json(404, {"error": "not found"})
            return
        self.send_response(200)
        self._headers(content_type, len(body))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        path = urlsplit(self.path).path
        if path in {"/", "/index.html"}:
            self._send_static("index.html", "text/html; charset=utf-8")
        elif path == "/app.js":
            self._send_static("app.js", "text/javascript; charset=utf-8")
        elif path == "/style.css":
            self._send_static("style.css", "text/css; charset=utf-8")
        elif path == "/healthz":
            self._send_json(
                200,
                {
                    "status": "ok",
                    "litellm_version": ACTUAL_VERSION,
                    "worker_running": _worker is not None and _worker.poll() is None,
                },
            )
        else:
            self._send_json(404, {"error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        if urlsplit(self.path).path != "/install-provider":
            self._send_json(404, {"error": "not found"})
            return

        try:
            length = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            length = -1
        if length < 1 or length > MAX_WHEEL_BYTES:
            self._send_json(413, {"error": "wheel must be between 1 byte and 1 MiB"})
            return

        supplied_name = self.headers.get("X-Wheel-Name", "provider.whl")
        filename = Path(supplied_name).name
        if filename != supplied_name or not filename.endswith(".whl"):
            self._send_json(400, {"error": "invalid wheel filename"})
            return

        body = self.rfile.read(length)
        wheel_path = UPLOAD_DIR / filename

        if not INSTALL_LOCK.acquire(timeout=30):
            self._send_json(503, {"status": "another installation is active"})
            return
        try:
            wheel_path.write_bytes(body)
            EVIDENCE_FILE.unlink(missing_ok=True)
            try:
                install = subprocess.run(
                    [
                        str(RUNTIME_PYTHON),
                        "-m",
                        "pip",
                        "install",
                        "--no-index",
                        "--no-deps",
                        "--no-compile",
                        "--disable-pip-version-check",
                        "--force-reinstall",
                        "--upgrade",
                        "--target",
                        str(RUNTIME_SITE),
                        str(wheel_path),
                    ],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=240,
                    env={**os.environ, "PIP_NO_INDEX": "1"},
                )
            except subprocess.TimeoutExpired:
                self._send_json(
                    504,
                    {"status": "install exceeded the execution window"},
                )
                return
            if install.returncode != 0:
                self._send_json(
                    400,
                    {"status": "install failed", "installer_tail": install.stdout[-2000:]},
                )
                return

            # Reset correlation state after installation so the response is
            # bound to the worker started below.
            EVIDENCE_FILE.unlink(missing_ok=True)
            _restart_worker()
            deadline = time.monotonic() + 20
            evidence = ""
            while time.monotonic() < deadline:
                try:
                    candidate = EVIDENCE_FILE.read_text(encoding="utf-8")
                    json.loads(candidate)
                except (OSError, ValueError):
                    pass
                else:
                    evidence = candidate[:4096]
                    break
                time.sleep(0.05)
            worker_log = WORKER_LOG.read_text(encoding="utf-8")[-4096:]
            if not evidence:
                self._send_json(
                    503,
                    {
                        "status": "worker did not publish a result",
                        "worker_log": worker_log,
                    },
                )
                return
            self._send_json(
                200,
                {
                    "status": "installed and worker restarted",
                    "evidence": evidence,
                    "worker_log": worker_log,
                },
            )
        finally:
            INSTALL_LOCK.release()


def _shutdown(_signum: int, _frame: object) -> None:
    _stop_worker()
    raise SystemExit(0)


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)
    _start_worker()
    server = ThreadingHTTPServer(("0.0.0.0", 8080), Handler)
    server.daemon_threads = True
    try:
        server.serve_forever()
    finally:
        _stop_worker()
