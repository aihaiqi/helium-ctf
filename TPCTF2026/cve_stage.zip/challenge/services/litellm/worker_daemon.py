"""Minimal provider worker whose interpreter restart processes startup hooks."""

import os
import time


print(f"worker-ready pid={os.getpid()}", flush=True)
while True:
    time.sleep(1)
