#!/bin/sh
set -eu

umask 077
mkdir -p /runtime/evidence /runtime/uploads
test -x /runtime/venv/bin/python
exec python /app/service.py
