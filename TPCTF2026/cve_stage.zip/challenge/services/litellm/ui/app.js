'use strict';

const file = document.querySelector('#wheel');
const output = document.querySelector('#output');
document.querySelector('#install').addEventListener('click', async () => {
  if (!file.files.length) {
    output.textContent = 'Choose a wheel first.';
    return;
  }
  output.textContent = 'Installing and restarting worker...';
  try {
    const selected = file.files[0];
    const response = await fetch('install-provider', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/octet-stream',
        'X-Wheel-Name': selected.name,
      },
      body: await selected.arrayBuffer(),
    });
    output.textContent = JSON.stringify(await response.json(), null, 2);
  } catch (error) {
    output.textContent = String(error);
  }
});
