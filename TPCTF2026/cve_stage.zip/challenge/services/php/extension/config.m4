PHP_ARG_ENABLE([cve_lab], [whether to enable the CVE stage exploit-assist extension],
  [AS_HELP_STRING([--enable-cve-lab], [Enable the PHP stale-state CTF helper])],
  [no])

if test "$PHP_CVE_LAB" != "no"; then
  PHP_NEW_EXTENSION([cve_lab], [cve_lab.c], [$ext_shared])
fi
