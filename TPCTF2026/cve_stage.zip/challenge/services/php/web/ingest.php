<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
echo json_encode([
    'service' => 'asterops-session-relay',
    'php' => PHP_VERSION,
    'sapi' => PHP_SAPI,
    'upload_progress' => ini_get('session.upload_progress.enabled'),
    'request' => 'parsed',
]);
