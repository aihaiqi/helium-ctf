"use strict";

const byId = (id) => document.getElementById(id);
const output = byId("output");
const state = byId("state");

function multipart(sessionName) {
  const form = new FormData();
  form.append("PHPSESSID", sessionName);
  form.append("PHP_SESSION_UPLOAD_PROGRESS", sessionName);
  form.append("upload", new Blob(["x"], {type: "text/plain"}), "x.txt");
  return form;
}

async function ingest(sessionName, command) {
  const headers = {};
  if (command) {
    headers["X-CVE-Command"] = command;
  }
  const response = await fetch("ingest.php", {
    method: "POST",
    headers,
    body: multipart(sessionName),
    credentials: "same-origin",
    cache: "no-store"
  });
  const body = await response.text();
  return `${response.status} ${response.statusText}\n${body}`;
}

async function queryResult() {
  const response = await fetch("result.php", {
    credentials: "same-origin",
    cache: "no-store"
  });
  const body = await response.text();
  return `${response.status} ${response.statusText}\n${body}`;
}

async function run(label, operation) {
  state.textContent = "working";
  output.textContent = `${label}...`;
  try {
    output.textContent = await operation();
    state.textContent = "complete";
  } catch (error) {
    output.textContent = String(error);
    state.textContent = "error";
  }
}

byId("producer").addEventListener("click", () => run("producer", () =>
  ingest(byId("producer-session").value, null)));

byId("consumer").addEventListener("click", () => run("consumer", () =>
  ingest(byId("consumer-session").value, byId("command").value)));

byId("result").addEventListener("click", () => run("result", queryResult));

byId("chain").addEventListener("click", () => run("sequence", async () => {
  const producer = await ingest(byId("producer-session").value, null);
  const consumer = await ingest(byId("consumer-session").value, byId("command").value);
  const result = await queryResult();
  return `== producer ==\n${producer}\n\n== consumer ==\n${consumer}\n\n== result ==\n${result}`;
}));
