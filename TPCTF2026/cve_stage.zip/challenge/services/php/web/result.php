<?php
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');
$path = '/tmp/stage-result';
if (!is_file($path)) {
    http_response_code(404);
    echo "not-fired\n";
    exit;
}
readfile($path);
