#define _POSIX_C_SOURCE 200112L

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define HEADER_LIMIT 32768
#define TOKEN_LIMIT 4096
#define BODY_LIMIT (64U * 1024U * 1024U)
#define LOCK_PAGE_LIMIT 32768
#define SESSION_BYTES 32
#define SESSION_HEX_LENGTH (SESSION_BYTES * 2)
#define SESSION_COOKIE "cve_stage_php"

typedef struct {
    int public_static;
    int root_request;
    int unlock_request;
    size_t content_length;
    const char *token;
    size_t token_length;
    unsigned int token_count;
    const char *cookie;
    size_t cookie_length;
    unsigned int cookie_count;
    unsigned char forwarded[HEADER_LIMIT + 64];
    size_t forwarded_length;
} request_info;

static int constant_time_equal(const char *left, size_t left_length,
        const char *right, size_t right_length);

static int send_all(int fd, const void *data, size_t length)
{
    const unsigned char *cursor = data;

    while (length > 0) {
        ssize_t sent = send(fd, cursor, length, MSG_NOSIGNAL);
        if (sent < 0 && errno == EINTR) {
            continue;
        }
        if (sent <= 0) {
            return -1;
        }
        cursor += (size_t) sent;
        length -= (size_t) sent;
    }
    return 0;
}

static void send_response(int fd, int status, const char *reason, const char *body)
{
    char response[512];
    int length = snprintf(response, sizeof(response),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: text/plain; charset=utf-8\r\n"
        "Content-Length: %zu\r\n"
        "Connection: close\r\n"
        "Cache-Control: no-store\r\n\r\n%s",
        status, reason, strlen(body), body);

    if (length > 0 && (size_t) length < sizeof(response)) {
        (void) send_all(fd, response, (size_t) length);
    }
}

static void send_unlock_response(int fd, const char *session_capability)
{
    char response[1024];
    int length = snprintf(response, sizeof(response),
        "HTTP/1.1 204 No Content\r\n"
        "Set-Cookie: " SESSION_COOKIE "=%s; Path=/php/; Max-Age=3600; HttpOnly; SameSite=Strict\r\n"
        "Content-Length: 0\r\n"
        "Connection: close\r\n"
        "Cache-Control: no-store\r\n\r\n",
        session_capability);

    if (length > 0 && (size_t) length < sizeof(response)) {
        (void) send_all(fd, response, (size_t) length);
    }
}

static void send_lock_page(int fd)
{
    unsigned char body[LOCK_PAGE_LIMIT];
    char response[512];
    FILE *file = fopen("/var/www/html/locked.html", "rb");
    size_t length;
    int header_length;

    if (file == NULL) {
        send_response(fd, 500, "Internal Server Error", "lock screen unavailable\n");
        return;
    }
    length = fread(body, 1, sizeof(body), file);
    if (ferror(file) || !feof(file)) {
        fclose(file);
        send_response(fd, 500, "Internal Server Error", "lock screen unavailable\n");
        return;
    }
    fclose(file);

    header_length = snprintf(response, sizeof(response),
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Content-Length: %zu\r\n"
        "Connection: close\r\n"
        "Cache-Control: no-store\r\n"
        "X-Content-Type-Options: nosniff\r\n\r\n",
        length);
    if (header_length > 0 && (size_t) header_length < sizeof(response)
            && send_all(fd, response, (size_t) header_length) == 0) {
        (void) send_all(fd, body, length);
    }
}

static int read_headers(int fd, unsigned char *headers, size_t *length)
{
    size_t used = 0;

    while (used < HEADER_LIMIT) {
        unsigned char byte;
        ssize_t count = recv(fd, &byte, 1, 0);

        if (count < 0 && errno == EINTR) {
            continue;
        }
        if (count <= 0 || byte == '\0') {
            return -1;
        }
        headers[used++] = byte;
        if (used >= 4 && memcmp(headers + used - 4, "\r\n\r\n", 4) == 0) {
            *length = used;
            return 0;
        }
    }
    return -2;
}

static int append_bytes(request_info *info, const void *data, size_t length)
{
    if (info->forwarded_length + length > sizeof(info->forwarded)) {
        return -1;
    }
    memcpy(info->forwarded + info->forwarded_length, data, length);
    info->forwarded_length += length;
    return 0;
}

static int header_name_is(const char *line, size_t name_length, const char *expected)
{
    return strlen(expected) == name_length
        && strncasecmp(line, expected, name_length) == 0;
}

static int parse_decimal_size(const char *value, size_t length, size_t *result)
{
    size_t parsed = 0;
    size_t i;

    if (length == 0) {
        return -1;
    }
    for (i = 0; i < length; i++) {
        unsigned int digit;
        if (!isdigit((unsigned char) value[i])) {
            return -1;
        }
        digit = (unsigned int) (value[i] - '0');
        if (parsed > (BODY_LIMIT - digit) / 10U) {
            return -1;
        }
        parsed = parsed * 10U + digit;
    }
    *result = parsed;
    return 0;
}

static int is_public_target(const char *method, const char *target)
{
    return strcmp(method, "GET") == 0 && strcmp(target, "/health.txt") == 0;
}

static int parse_request(const unsigned char *headers, size_t length, request_info *info)
{
    char parsed[HEADER_LIMIT + 1];
    char *line;
    char *next;
    char method[16];
    char target[2048];
    char version[16];
    char extra[2];
    unsigned int content_length_count = 0;

    memset(info, 0, sizeof(*info));
    memcpy(parsed, headers, length);
    parsed[length] = '\0';

    line = parsed;
    next = strstr(line, "\r\n");
    if (next == NULL) {
        return -1;
    }
    *next = '\0';
    if (sscanf(line, "%15s %2047s %15s %1s", method, target, version, extra) != 3
            || strncmp(version, "HTTP/1.", 7) != 0) {
        return -1;
    }
    info->public_static = is_public_target(method, target);
    info->root_request = strcmp(method, "GET") == 0 && strcmp(target, "/") == 0;
    info->unlock_request = strcmp(method, "POST") == 0 && strcmp(target, "/unlock") == 0;
    if (append_bytes(info, line, strlen(line)) < 0
            || append_bytes(info, "\r\n", 2) < 0) {
        return -1;
    }

    line = next + 2;
    while (*line != '\0') {
        char *colon;
        char *value;
        char *end;
        size_t name_length;
        size_t value_length;
        size_t raw_length;
        int omit = 0;

        next = strstr(line, "\r\n");
        if (next == NULL) {
            return -1;
        }
        if (next == line) {
            break;
        }
        raw_length = (size_t) (next - line);
        colon = memchr(line, ':', raw_length);
        if (colon == NULL || colon == line) {
            return -1;
        }
        name_length = (size_t) (colon - line);
        if (isspace((unsigned char) line[name_length - 1])) {
            return -1;
        }
        value = colon + 1;
        end = next;
        while (value < end && (*value == ' ' || *value == '\t')) {
            value++;
        }
        while (end > value && (end[-1] == ' ' || end[-1] == '\t')) {
            end--;
        }
        value_length = (size_t) (end - value);

        if (header_name_is(line, name_length, "X-Stage-Token")) {
            info->token = (const char *) headers + (value - parsed);
            info->token_length = value_length;
            info->token_count++;
            omit = 1;
        } else if (header_name_is(line, name_length, "Cookie")) {
            info->cookie = (const char *) headers + (value - parsed);
            info->cookie_length = value_length;
            info->cookie_count++;
            omit = 1;
        } else if (header_name_is(line, name_length, "Connection")
                || header_name_is(line, name_length, "Proxy-Connection")) {
            omit = 1;
        } else if (header_name_is(line, name_length, "Transfer-Encoding")) {
            return -1;
        } else if (header_name_is(line, name_length, "Content-Length")) {
            content_length_count++;
            if (content_length_count != 1
                    || parse_decimal_size(value, value_length, &info->content_length) < 0) {
                return -1;
            }
        }

        if (!omit && (append_bytes(info, line, raw_length) < 0
                || append_bytes(info, "\r\n", 2) < 0)) {
            return -1;
        }
        line = next + 2;
    }

    if (info->public_static && info->content_length != 0) {
        return -1;
    }
    if (append_bytes(info, "Connection: close\r\n\r\n", 21) < 0) {
        return -1;
    }
    return 0;
}

static int cookie_has_capability(const char *cookie, size_t cookie_length,
        const char *session_capability)
{
    size_t position = 0;
    unsigned int matches = 0;
    int valid = 0;

    while (position < cookie_length) {
        size_t start;
        size_t end;
        size_t equals;

        while (position < cookie_length
                && (cookie[position] == ' ' || cookie[position] == '\t'
                    || cookie[position] == ';')) {
            position++;
        }
        start = position;
        while (position < cookie_length && cookie[position] != ';') {
            position++;
        }
        end = position;
        while (end > start && (cookie[end - 1] == ' ' || cookie[end - 1] == '\t')) {
            end--;
        }
        equals = start;
        while (equals < end && cookie[equals] != '=') {
            equals++;
        }
        if (equals < end
                && equals - start == strlen(SESSION_COOKIE)
                && memcmp(cookie + start, SESSION_COOKIE, strlen(SESSION_COOKIE)) == 0) {
            size_t value_start = equals + 1;
            matches++;
            valid = constant_time_equal(cookie + value_start, end - value_start,
                session_capability, SESSION_HEX_LENGTH);
        }
    }
    return matches == 1 && valid;
}

static int generate_session_capability(char *capability)
{
    static const char hexadecimal[] = "0123456789abcdef";
    unsigned char random_bytes[SESSION_BYTES];
    FILE *file = fopen("/dev/urandom", "rb");
    size_t i;

    if (file == NULL
            || fread(random_bytes, 1, sizeof(random_bytes), file) != sizeof(random_bytes)) {
        if (file != NULL) {
            fclose(file);
        }
        return -1;
    }
    fclose(file);
    for (i = 0; i < sizeof(random_bytes); i++) {
        capability[i * 2] = hexadecimal[random_bytes[i] >> 4];
        capability[i * 2 + 1] = hexadecimal[random_bytes[i] & 0x0f];
    }
    capability[SESSION_HEX_LENGTH] = '\0';
    return 0;
}

static int constant_time_equal(const char *left, size_t left_length,
        const char *right, size_t right_length)
{
    size_t i;
    unsigned int difference = left_length != right_length;
    size_t maximum = left_length > right_length ? left_length : right_length;

    for (i = 0; i < maximum; i++) {
        unsigned char a = i < left_length ? (unsigned char) left[i] : 0;
        unsigned char b = i < right_length ? (unsigned char) right[i] : 0;
        difference |= (unsigned int) (a ^ b);
    }
    return difference == 0;
}

static int load_token(const char *path, char *token, size_t *length)
{
    FILE *file = fopen(path, "rb");
    size_t used;

    if (file == NULL) {
        return -1;
    }
    used = fread(token, 1, TOKEN_LIMIT, file);
    if (ferror(file) || !feof(file)) {
        fclose(file);
        return -1;
    }
    fclose(file);
    while (used > 0 && (token[used - 1] == '\n' || token[used - 1] == '\r')) {
        used--;
    }
    if (used == 0) {
        return -1;
    }
    *length = used;
    return 0;
}

static int connect_target(const char *host, const char *port)
{
    struct addrinfo hints;
    struct addrinfo *addresses = NULL;
    struct addrinfo *address;
    int fd = -1;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(host, port, &hints, &addresses) != 0) {
        return -1;
    }
    for (address = addresses; address != NULL; address = address->ai_next) {
        fd = socket(address->ai_family, address->ai_socktype, address->ai_protocol);
        if (fd >= 0 && connect(fd, address->ai_addr, address->ai_addrlen) == 0) {
            break;
        }
        if (fd >= 0) {
            close(fd);
            fd = -1;
        }
    }
    freeaddrinfo(addresses);
    return fd;
}

static int forward_body(int client, int target, size_t remaining)
{
    unsigned char buffer[16384];

    while (remaining > 0) {
        size_t wanted = remaining < sizeof(buffer) ? remaining : sizeof(buffer);
        ssize_t count = recv(client, buffer, wanted, 0);
        if (count < 0 && errno == EINTR) {
            continue;
        }
        if (count <= 0 || send_all(target, buffer, (size_t) count) < 0) {
            return -1;
        }
        remaining -= (size_t) count;
    }
    return 0;
}

static void forward_response(int target, int client)
{
    unsigned char buffer[16384];

    for (;;) {
        ssize_t count = recv(target, buffer, sizeof(buffer), 0);
        if (count < 0 && errno == EINTR) {
            continue;
        }
        if (count <= 0 || send_all(client, buffer, (size_t) count) < 0) {
            return;
        }
    }
}

static void handle_connection(int client, const char *host, const char *port,
        const char *expected_token, size_t expected_length,
        const char *session_capability)
{
    unsigned char headers[HEADER_LIMIT];
    size_t header_length;
    request_info info;
    int target;
    int authenticated;
    int read_result = read_headers(client, headers, &header_length);

    if (read_result == -2) {
        send_response(client, 431, "Request Header Fields Too Large", "headers too large\n");
        return;
    }
    if (read_result < 0 || parse_request(headers, header_length, &info) < 0) {
        send_response(client, 400, "Bad Request", "bad request\n");
        return;
    }
    authenticated = info.cookie_count == 1
        && cookie_has_capability(info.cookie, info.cookie_length, session_capability);

    if (info.unlock_request) {
        if (info.content_length != 0) {
            send_response(client, 400, "Bad Request", "unlock request must be empty\n");
            return;
        }
        if (info.token_count != 1
                || !constant_time_equal(info.token, info.token_length,
                    expected_token, expected_length)) {
            send_response(client, 401, "Unauthorized", "invalid secret\n");
            return;
        }
        send_unlock_response(client, session_capability);
        return;
    }
    if (info.root_request && !authenticated) {
        if (info.content_length != 0) {
            send_response(client, 400, "Bad Request", "bad request\n");
            return;
        }
        send_lock_page(client);
        return;
    }
    if (!info.public_static && !authenticated) {
        send_response(client, 401, "Unauthorized", "unauthorized\n");
        return;
    }

    target = connect_target(host, port);
    if (target < 0) {
        send_response(client, 502, "Bad Gateway", "backend unavailable\n");
        return;
    }
    if (send_all(target, info.forwarded, info.forwarded_length) < 0
            || forward_body(client, target, info.content_length) < 0) {
        close(target);
        return;
    }
    shutdown(target, SHUT_WR);
    forward_response(target, client);
    close(target);
}

int main(int argc, char **argv)
{
    struct sockaddr_in listen_address;
    char token[TOKEN_LIMIT];
    char session_capability[SESSION_HEX_LENGTH + 1];
    size_t token_length;
    int listener;
    int one = 1;

    if (argc != 5) {
        fprintf(stderr, "usage: %s LISTEN_PORT TARGET_HOST TARGET_PORT TOKEN_FILE\n", argv[0]);
        return 2;
    }
    if (load_token(argv[4], token, &token_length) < 0) {
        fprintf(stderr, "gate token is missing or invalid\n");
        return 3;
    }
    if (generate_session_capability(session_capability) < 0) {
        fprintf(stderr, "could not initialize gate session\n");
        return 4;
    }

    signal(SIGCHLD, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);
    listener = socket(AF_INET, SOCK_STREAM, 0);
    if (listener < 0) {
        return 5;
    }
    (void) setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    memset(&listen_address, 0, sizeof(listen_address));
    listen_address.sin_family = AF_INET;
    listen_address.sin_addr.s_addr = htonl(INADDR_ANY);
    listen_address.sin_port = htons((unsigned short) strtoul(argv[1], NULL, 10));
    if (bind(listener, (struct sockaddr *) &listen_address, sizeof(listen_address)) < 0
            || listen(listener, 32) < 0) {
        close(listener);
        return 6;
    }

    for (;;) {
        int client = accept(listener, NULL, NULL);
        pid_t child;

        if (client < 0) {
            if (errno == EINTR) {
                continue;
            }
            close(listener);
            return 7;
        }
        child = fork();
        if (child < 0) {
            close(client);
            continue;
        }
        if (child == 0) {
            close(listener);
            handle_connection(client, argv[2], argv[3], token, token_length,
                session_capability);
            close(client);
            _exit(0);
        }
        close(client);
    }
}
