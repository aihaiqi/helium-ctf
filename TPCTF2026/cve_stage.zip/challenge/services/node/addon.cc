#include <node_api.h>

#include <atomic>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstring>

#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

extern "C" {
#include <brotli/decode.h>
}

namespace {

constexpr const char* kProofPath = "/tmp/node-rce-proof.txt";
constexpr size_t kMaximumSecretBytes = 4096;
std::atomic<bool> proof_written{false};
thread_local char proof_nonce[33] = {};

void WriteAll(int fd, const char* data, size_t length) {
  while (length != 0) {
    ssize_t written = write(fd, data, length);
    if (written < 0) {
      if (errno == EINTR) continue;
      return;
    }
    data += static_cast<size_t>(written);
    length -= static_cast<size_t>(written);
  }
}

void AppendRuntimeValue(int output_fd, const char* label, const char* path) {
  WriteAll(output_fd, label, std::strlen(label));

  int input_fd = open(path, O_RDONLY | O_CLOEXEC);
  if (input_fd < 0) {
    const char unavailable[] = "[unavailable]\n";
    WriteAll(output_fd, unavailable, sizeof(unavailable) - 1);
    return;
  }

  size_t total = 0;
  char last = '\0';
  char buffer[256];
  while (total < kMaximumSecretBytes) {
    size_t wanted = sizeof(buffer);
    if (wanted > kMaximumSecretBytes - total) {
      wanted = kMaximumSecretBytes - total;
    }
    ssize_t count = read(input_fd, buffer, wanted);
    if (count == 0) break;
    if (count < 0) {
      if (errno == EINTR) continue;
      break;
    }
    WriteAll(output_fd, buffer, static_cast<size_t>(count));
    total += static_cast<size_t>(count);
    last = buffer[count - 1];
  }
  close(input_fd);

  if (last != '\n') {
    const char newline = '\n';
    WriteAll(output_fd, &newline, 1);
  }
}

napi_value MakeInt(napi_env env, int32_t value) {
  napi_value result;
  napi_create_int32(env, value, &result);
  return result;
}

napi_value MakeUint(napi_env env, uint32_t value) {
  napi_value result;
  napi_create_uint32(env, value, &result);
  return result;
}

void Set(napi_env env, napi_value object, const char* name, napi_value value) {
  napi_set_named_property(env, object, name, value);
}

struct StepResult {
  BrotliDecoderResult result;
  BrotliDecoderErrorCode error;
  size_t remaining;
};

StepResult Feed(BrotliDecoderState* state, const uint8_t* input,
                size_t input_size) {
  size_t available_in = input_size;
  const uint8_t* next_in = input;
  uint8_t output[4096];
  size_t available_out = sizeof(output);
  uint8_t* next_out = output;
  size_t total_out = 0;

  BrotliDecoderResult result = BrotliDecoderDecompressStream(
      state, &available_in, &next_in, &available_out, &next_out, &total_out);
  return {result, BrotliDecoderGetErrorCode(state), available_in};
}

napi_value DecodeTwoChunks(napi_env env, napi_callback_info info) {
  size_t argc = 3;
  napi_value argv[3];
  napi_get_cb_info(env, info, &argc, argv, nullptr, nullptr);

  if (argc != 3) {
    napi_throw_type_error(env, nullptr,
                          "two Buffer arguments and a proof nonce are required");
    return nullptr;
  }

  bool first_is_buffer = false;
  bool second_is_buffer = false;
  napi_is_buffer(env, argv[0], &first_is_buffer);
  napi_is_buffer(env, argv[1], &second_is_buffer);
  if (!first_is_buffer || !second_is_buffer) {
    napi_throw_type_error(env, nullptr, "arguments must be Buffer objects");
    return nullptr;
  }

  napi_valuetype nonce_type;
  napi_typeof(env, argv[2], &nonce_type);
  size_t nonce_length = 0;
  if (nonce_type != napi_string ||
      napi_get_value_string_utf8(env, argv[2], nullptr, 0, &nonce_length) != napi_ok ||
      nonce_length != 32) {
    napi_throw_type_error(env, nullptr, "proof nonce must be 32 lowercase hex characters");
    return nullptr;
  }
  size_t nonce_written = 0;
  napi_get_value_string_utf8(env, argv[2], proof_nonce, sizeof(proof_nonce),
                             &nonce_written);
  for (size_t index = 0; index < nonce_written; ++index) {
    const char value = proof_nonce[index];
    if (!((value >= '0' && value <= '9') || (value >= 'a' && value <= 'f'))) {
      napi_throw_type_error(env, nullptr,
                            "proof nonce must be 32 lowercase hex characters");
      return nullptr;
    }
  }
  if (nonce_written != 32) {
    napi_throw_type_error(env, nullptr, "proof nonce length changed during conversion");
    return nullptr;
  }
  proof_nonce[32] = '\0';
  proof_written.store(false);
  if (unlink(kProofPath) != 0 && errno != ENOENT) {
    napi_throw_error(env, nullptr, "could not clear the previous proof");
    return nullptr;
  }

  void* first_data = nullptr;
  void* second_data = nullptr;
  size_t first_size = 0;
  size_t second_size = 0;
  napi_get_buffer_info(env, argv[0], &first_data, &first_size);
  napi_get_buffer_info(env, argv[1], &second_data, &second_size);

  BrotliDecoderState* state =
      BrotliDecoderCreateInstance(nullptr, nullptr, nullptr);
  if (state == nullptr) {
    napi_throw_error(env, nullptr, "BrotliDecoderCreateInstance failed");
    return nullptr;
  }

  StepResult first = Feed(state, static_cast<uint8_t*>(first_data), first_size);
  StepResult second = Feed(state, static_cast<uint8_t*>(second_data), second_size);
  BrotliDecoderDestroyInstance(state);

  napi_value object;
  napi_create_object(env, &object);
  Set(env, object, "firstResult", MakeInt(env, static_cast<int32_t>(first.result)));
  Set(env, object, "firstError", MakeInt(env, static_cast<int32_t>(first.error)));
  Set(env, object, "firstRemaining",
      MakeUint(env, static_cast<uint32_t>(first.remaining)));
  Set(env, object, "secondResult", MakeInt(env, static_cast<int32_t>(second.result)));
  Set(env, object, "secondError", MakeInt(env, static_cast<int32_t>(second.error)));
  Set(env, object, "secondRemaining",
      MakeUint(env, static_cast<uint32_t>(second.remaining)));

  napi_value triggered;
  napi_get_boolean(env, proof_written.load(), &triggered);
  Set(env, object, "controlFlowTriggered", triggered);
  return object;
}

}  // namespace

extern "C" __attribute__((visibility("default")))
void BrotliCtfHarnessControlFlow(void) {
  if (proof_written.exchange(true)) return;

  int output_fd = open(kProofPath,
                       O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
  if (output_fd < 0) return;

  const char marker[] =
      "MARKER=NODE_CVE_2026_111497_CONTROL_FLOW\n";
  WriteAll(output_fd, marker, sizeof(marker) - 1);
  WriteAll(output_fd, "REQUEST_NONCE=", sizeof("REQUEST_NONCE=") - 1);
  WriteAll(output_fd, proof_nonce, std::strlen(proof_nonce));
  WriteAll(output_fd, "\nCOMMAND=/usr/bin/id\n",
           sizeof("\nCOMMAND=/usr/bin/id\n") - 1);

  pid_t child = fork();
  if (child == 0) {
    dup2(output_fd, STDOUT_FILENO);
    dup2(output_fd, STDERR_FILENO);
    execl("/usr/bin/id", "id", static_cast<char*>(nullptr));
    _exit(127);
  }
  if (child > 0) {
    int status = 0;
    while (waitpid(child, &status, 0) < 0 && errno == EINTR) {
    }
  }

  AppendRuntimeValue(output_fd, "FLAG=", "/run/ctf/flag");
  AppendRuntimeValue(output_fd, "NEXT_TOKEN=", "/run/ctf/next-token");
  fsync(output_fd);
  close(output_fd);
}

NAPI_MODULE_INIT() {
  napi_value function;
  napi_create_function(env, "decodeTwoChunks", NAPI_AUTO_LENGTH,
                       DecodeTwoChunks, nullptr, &function);
  napi_set_named_property(env, exports, "decodeTwoChunks", function);
  return exports;
}
