'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const http = require('node:http');
const zlib = require('node:zlib');
const addon = require('/app/ctf_brotli.node');

const GATE_PATH = '/run/ctf/gate-token';
const PROOF_PATH = '/tmp/node-rce-proof.txt';
const SESSION_COOKIE = 'cve_stage_node';
const SESSION_CAPABILITY = crypto.randomBytes(32).toString('hex');
const SESSION_MAX_AGE = 1800;
const MAX_GZIP_BODY = 1024 * 1024;
const MAX_DECODED_BODY = 24 * 1024 * 1024;

const LOCK_PAGE = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>AsterOps Decoder Relay</title>
  <style>
    :root { color-scheme: dark; font: 16px/1.45 system-ui, sans-serif; }
    * { box-sizing: border-box; }
    body { min-height: 100vh; margin: 0; display: grid; place-items: center;
      background: radial-gradient(circle at top, #172b4d 0, #0b1220 45%, #050914 100%);
      color: #dbeafe; }
    main { width: min(430px, calc(100% - 32px)); }
    section { padding: 32px; border: 1px solid #294264; border-radius: 16px;
      background: #101b2ee8; box-shadow: 0 24px 70px #020617bb; }
    .lock { width: 48px; height: 48px; display: grid; place-items: center; margin-bottom: 20px;
      border-radius: 14px; background: #1d4ed833; border: 1px solid #3b82f680; font-size: 24px; }
    h1 { margin: 0 0 8px; font-size: 1.55rem; }
    p { margin: 0 0 22px; color: #9fb4cf; }
    label { display: block; margin-bottom: 7px; font-weight: 650; }
    input, button { width: 100%; border-radius: 8px; border: 1px solid #385476;
      padding: 11px 12px; font: inherit; }
    input { background: #09111f; color: #e5f0ff; }
    input:focus { outline: 2px solid #3b82f6; outline-offset: 2px; }
    button { margin-top: 14px; background: #1d4ed8; border-color: #3b82f6;
      color: white; cursor: pointer; font-weight: 750; }
    button:disabled { cursor: wait; opacity: .7; }
    #message { min-height: 1.4em; margin: 14px 0 0; color: #fca5a5; font-size: .92rem; }
  </style>
</head>
<body>
<main>
  <section>
    <div class="lock" aria-hidden="true">&#128274;</div>
    <h1>Decoder Relay Locked</h1>
    <p>Enter the secret recovered from the previous checkpoint to open this panel.</p>
    <form id="unlock-form">
      <label for="secret">Checkpoint secret</label>
      <input id="secret" type="password" autocomplete="off" autofocus required>
      <button id="unlock-button" type="submit">Unlock panel</button>
    </form>
    <p id="message" role="status" aria-live="polite"></p>
  </section>
</main>
<script>
  const form = document.querySelector('#unlock-form');
  const secret = document.querySelector('#secret');
  const button = document.querySelector('#unlock-button');
  const message = document.querySelector('#message');
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    button.disabled = true;
    message.textContent = 'Checking secret…';
    try {
      const response = await fetch('unlock', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'X-Stage-Token': secret.value },
      });
      if (response.ok) {
        window.location.reload();
        return;
      }
      message.textContent = 'That secret was not accepted.';
    } catch {
      message.textContent = 'The relay is unavailable. Try again.';
    }
    button.disabled = false;
  });
</script>
</body>
</html>`;

const PAGE = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>AsterOps Decoder Relay</title>
  <style>
    :root { color-scheme: dark; font: 16px/1.45 system-ui, sans-serif; }
    body { margin: 0; background: #0b1220; color: #dbeafe; }
    main { width: min(760px, calc(100% - 32px)); margin: 48px auto; }
    section { background: #111c31; border: 1px solid #294264; border-radius: 12px;
      padding: 24px; box-shadow: 0 16px 48px #03071299; }
    h1 { margin: 0 0 8px; font-size: 1.65rem; }
    p { color: #9fb4cf; }
    label { display: block; margin: 14px 0 5px; font-weight: 650; }
    input, select, button { box-sizing: border-box; width: 100%; border-radius: 7px;
      border: 1px solid #385476; background: #09111f; color: #e5f0ff; padding: 10px; }
    .row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    button { margin-top: 16px; background: #1d4ed8; border-color: #3b82f6;
      cursor: pointer; font-weight: 700; }
    button.secondary { background: #17263d; }
    pre { min-height: 90px; overflow: auto; white-space: pre-wrap; word-break: break-word;
      background: #050a13; border: 1px solid #263a55; border-radius: 7px; padding: 12px; }
    code { color: #93c5fd; }
    small { color: #87a1bf; }
    @media (max-width: 560px) { .row { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
<main>
  <section>
    <h1>AsterOps / Decoder Relay</h1>
    <p>Brotli diagnostic endpoint. Supply an exact decoder stream and the split
      offset used for the two streaming calls.</p>
    <form id="decode-form">
      <label for="payload">Payload file</label>
      <input id="payload" type="file" required>
      <div class="row">
        <div>
          <label for="split">Decoded chunk 1 length</label>
          <input id="split" type="number" min="1" step="1" required>
        </div>
        <div>
          <label for="encoding">Uploaded file encoding</label>
          <select id="encoding">
            <option value="gzip">gzip (up to 1 MiB)</option>
            <option value="identity">raw (up to 24 MiB)</option>
          </select>
        </div>
      </div>
      <small>The split offset always refers to bytes after optional gzip decompression.</small>
      <button type="submit">Run decoder</button>
      <button id="proof-button" class="secondary" type="button">Read execution proof</button>
    </form>
    <label>Response</label>
    <pre id="output">Ready.</pre>
  </section>
</main>
<script>
  const output = document.querySelector('#output');
  let proofNonce = '';

  async function showResponse(response) {
    const text = await response.text();
    output.textContent = 'HTTP ' + response.status + '\\n' + text;
    return text;
  }

  document.querySelector('#decode-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const file = document.querySelector('#payload').files[0];
    if (!file) return;
    output.textContent = 'Uploading…';
    const headers = {
      'Content-Type': 'application/octet-stream',
      'X-Chunk1-Length': document.querySelector('#split').value,
    };
    if (document.querySelector('#encoding').value === 'gzip') {
      headers['Content-Encoding'] = 'gzip';
    }
    try {
      const response = await fetch('decode', {
        method: 'POST', headers, body: await file.arrayBuffer(),
      });
      const text = await showResponse(response);
      try {
        const result = JSON.parse(text);
        proofNonce = typeof result.proofNonce === 'string' ? result.proofNonce : '';
      } catch {
        proofNonce = '';
      }
    } catch (error) {
      output.textContent = String(error);
    }
  });

  document.querySelector('#proof-button').addEventListener('click', async () => {
    output.textContent = 'Reading proof…';
    try {
      const response = await fetch('proof', {
        headers: { 'X-Proof-Nonce': proofNonce },
      });
      await showResponse(response);
    } catch (error) {
      output.textContent = String(error);
    }
  });
</script>
</body>
</html>`;

function send(res, status, body, type = 'application/json', close = false, extraHeaders = {}) {
  const headers = {
    'content-type': `${type}; charset=utf-8`,
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  };
  if (close) headers.connection = 'close';
  Object.assign(headers, extraHeaders);
  res.writeHead(status, headers);
  res.end(body);
}

function headerString(req, name) {
  const value = req.headers[name];
  return typeof value === 'string' ? value : '';
}

function unlockTokenAccepted(req) {
  let expected = '';
  try {
    expected = fs.readFileSync(GATE_PATH, 'utf8').replace(/[\r\n]+$/u, '');
  } catch {
    // Still perform the fixed-size digest comparison below.
  }
  const supplied = headerString(req, 'x-stage-token');
  const expectedDigest = crypto.createHash('sha256').update(expected).digest();
  const suppliedDigest = crypto.createHash('sha256').update(supplied).digest();
  const equal = crypto.timingSafeEqual(expectedDigest, suppliedDigest);
  return expected.length > 0 && supplied.length > 0 && equal;
}

function sessionAccepted(req) {
  const cookieHeader = headerString(req, 'cookie');
  const supplied = cookieHeader.split(';').map((part) => part.trim())
    .filter((part) => part.startsWith(`${SESSION_COOKIE}=`));
  if (supplied.length !== 1) return false;
  const value = supplied[0].slice(SESSION_COOKIE.length + 1);
  if (!/^[0-9a-f]{64}$/u.test(value)) return false;
  return crypto.timingSafeEqual(Buffer.from(SESSION_CAPABILITY), Buffer.from(value));
}

function requireSession(req, res) {
  if (sessionAccepted(req)) return true;
  send(res, 401, JSON.stringify({ error: 'stage is locked' }), 'application/json', true);
  return false;
}

function parseSplit(req) {
  const raw = headerString(req, 'x-chunk1-length');
  if (!/^[1-9][0-9]{0,8}$/u.test(raw)) return null;
  const value = Number(raw);
  return Number.isSafeInteger(value) && value < MAX_DECODED_BODY ? value : null;
}

function collectBody(req, res, maximum, done) {
  const pieces = [];
  let length = 0;
  let rejected = false;

  const declared = headerString(req, 'content-length');
  if (declared && (!/^[0-9]+$/u.test(declared) || Number(declared) > maximum)) {
    send(res, 413, JSON.stringify({ error: 'request body too large' }), 'application/json', true);
    return;
  }

  req.on('data', (piece) => {
    if (rejected) return;
    length += piece.length;
    if (length > maximum) {
      rejected = true;
      pieces.length = 0;
      send(res, 413, JSON.stringify({ error: 'request body too large' }), 'application/json', true);
      return;
    }
    pieces.push(piece);
  });
  req.on('end', () => {
    if (!rejected) done(Buffer.concat(pieces, length));
  });
  req.on('error', () => {
    if (!rejected && !res.headersSent) {
      rejected = true;
      send(res, 400, JSON.stringify({ error: 'request failed' }));
    }
  });
}

function decodeRequest(req, res) {
  if (!requireSession(req, res)) return;

  const split = parseSplit(req);
  if (split === null) {
    send(res, 400, JSON.stringify({ error: 'invalid x-chunk1-length' }));
    return;
  }

  const encoding = headerString(req, 'content-encoding').toLowerCase() || 'identity';
  if (encoding !== 'identity' && encoding !== 'gzip') {
    send(res, 415, JSON.stringify({ error: 'content-encoding must be identity or gzip' }));
    return;
  }

  const wireLimit = encoding === 'gzip' ? MAX_GZIP_BODY : MAX_DECODED_BODY;
  collectBody(req, res, wireLimit, (wireBody) => {
    let body = wireBody;
    if (encoding === 'gzip') {
      try {
        body = zlib.gunzipSync(wireBody, { maxOutputLength: MAX_DECODED_BODY });
      } catch {
        send(res, 400, JSON.stringify({ error: 'invalid or oversized gzip body' }));
        return;
      }
    }

    if (body.length > MAX_DECODED_BODY) {
      send(res, 413, JSON.stringify({ error: 'decoded body too large' }));
      return;
    }
    if (body.length <= split) {
      send(res, 400, JSON.stringify({ error: 'second decoder chunk missing' }));
      return;
    }

    try {
      const proofNonce = crypto.randomBytes(16).toString('hex');
      const result = addon.decodeTwoChunks(
        body.subarray(0, split),
        body.subarray(split),
        proofNonce,
      );
      result.proofNonce = proofNonce;
      send(res, 200, JSON.stringify(result));
    } catch {
      send(res, 500, JSON.stringify({ error: 'decoder invocation failed' }));
    }
  });
}

const server = http.createServer((req, res) => {
  let pathname = '/';
  try {
    pathname = new URL(req.url, 'http://service.invalid').pathname;
  } catch {
    send(res, 400, JSON.stringify({ error: 'invalid request target' }));
    return;
  }

  if (req.method === 'GET' && pathname === '/') {
    send(res, 200, sessionAccepted(req) ? PAGE : LOCK_PAGE, 'text/html');
    return;
  }
  if (req.method === 'GET' && pathname === '/health') {
    send(res, 200, JSON.stringify({ ok: true, stage: 'node', node: process.version }));
    return;
  }
  if (req.method === 'POST' && pathname === '/unlock') {
    if (!unlockTokenAccepted(req)) {
      send(res, 401, JSON.stringify({ error: 'invalid checkpoint secret' }), 'application/json', true);
      return;
    }
    const cookie = `${SESSION_COOKIE}=${SESSION_CAPABILITY}; Path=/node/; Max-Age=${SESSION_MAX_AGE}; HttpOnly; SameSite=Strict`;
    send(res, 200, JSON.stringify({ unlocked: true }), 'application/json', false, {
      'set-cookie': cookie,
    });
    return;
  }
  if (req.method === 'GET' && pathname === '/proof') {
    if (!requireSession(req, res)) return;
    try {
      const proof = fs.readFileSync(PROOF_PATH, 'utf8');
      const nonceMatch = /^REQUEST_NONCE=([0-9a-f]{32})$/mu.exec(proof);
      const suppliedNonce = headerString(req, 'x-proof-nonce');
      const nonceAccepted = nonceMatch !== null && /^[0-9a-f]{32}$/u.test(suppliedNonce)
        && crypto.timingSafeEqual(Buffer.from(nonceMatch[1]), Buffer.from(suppliedNonce));
      if (!nonceAccepted) {
        send(res, 404, JSON.stringify({ proof: false }));
        return;
      }
      fs.unlinkSync(PROOF_PATH);
      send(res, 200, proof, 'text/plain');
    } catch (error) {
      if (error.code === 'ENOENT') {
        send(res, 404, JSON.stringify({ proof: false }));
      } else {
        send(res, 500, JSON.stringify({ error: 'proof read failed' }));
      }
    }
    return;
  }
  if (req.method === 'POST' && pathname === '/decode') {
    decodeRequest(req, res);
    return;
  }
  send(res, 404, JSON.stringify({ error: 'not found' }));
});

server.requestTimeout = 120_000;
server.headersTimeout = 125_000;
server.keepAliveTimeout = 5_000;
server.maxHeadersCount = 32;
server.listen(3000, '0.0.0.0');
