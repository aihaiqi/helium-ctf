package main

import (
	"archive/zip"
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"embed"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync/atomic"
	"time"
)

const (
	listenAddress  = "0.0.0.0:8080"
	proxyAddress   = "127.0.0.1:8081"
	healthURL      = "http://127.0.0.1:8080/health"
	gateTokenPath  = "/run/fixture/gate-token"
	toolchainName  = "go1.27.99"
	toolchainMod   = "golang.org/toolchain"
	toolchainVer   = "v0.0.1-go1.27.99.linux-amd64"
	moduleRoot     = toolchainMod + "@" + toolchainVer
	dependencyMod  = "attacker.example/future"
	dependencyVer  = "v1.0.0"
	dependencyRoot = dependencyMod + "@" + dependencyVer
	goBinary       = "/opt/go/bin/go"
	maxOutputBytes = 32 * 1024
	maxBodyBytes   = 4096
	buildTimeout   = 60 * time.Second
	sessionCookie  = "cve_stage_go"
	sessionMaxAge  = 30 * time.Minute
)

//go:embed index.html lock.html
var uiFiles embed.FS

var proxyGoMod = []byte("module golang.org/toolchain\n")

var dependencyGoMod = []byte("module attacker.example/future\n\ngo 1.27.99\n")

var dependencySource = []byte("package future\n")

// The replacement toolchain fixture includes a minimal bin/go executable.
// When selected by cmd/go, it emits one bounded proof by reading this stage's
// mounted answer into a nonce-bound marker.
var fakeGo = []byte(`#!/bin/sh
set -eu
answer=$(/bin/cat /run/fixture/flag)
/usr/bin/printf 'MARKER=GO94447_EXEC:%s\nFLAG=%s\n' "${LAB_NONCE}" "${answer}" > "${LAB_MARKER_PATH}"
/usr/bin/printf '%s\n' 'replacement toolchain bin/go executed'
exit 73
`)

type fixture struct {
	zipBytes      []byte
	dependencyZip []byte
	moduleSum     string
	goModSum      string
	zipSHA256     string
	proxyRequests atomic.Uint64
}

type application struct {
	fixture      *fixture
	gateHash     [sha256.Size]byte
	sessionValue string
	sessionHash  [sha256.Size]byte
	sessionUntil atomic.Int64
	buildLimiter chan struct{}
}

type attackMetadata struct {
	Toolchain      string `json:"toolchain"`
	ModuleVersion  string `json:"module_version"`
	ModuleSum      string `json:"module_sum"`
	GoModSum       string `json:"gomod_sum"`
	ProxyZipSHA256 string `json:"proxy_zip_sha256"`
}

type buildRequest struct {
	Toolchain string `json:"toolchain"`
	ModuleSum string `json:"module_sum"`
	GoModSum  string `json:"gomod_sum"`
}

type buildResponse struct {
	RuntimeVersion     string `json:"runtime_version"`
	RequestedToolchain string `json:"requested_toolchain"`
	Nonce              string `json:"nonce"`
	Executed           bool   `json:"executed"`
	Marker             string `json:"marker,omitempty"`
	MarkerSHA256       string `json:"marker_sha256,omitempty"`
	CommandExit        int    `json:"command_exit"`
	CommandError       string `json:"command_error,omitempty"`
	GoOutput           string `json:"go_output"`
	ProxyRequests      uint64 `json:"proxy_requests"`
}

type cappedBuffer struct {
	b bytes.Buffer
	n int
}

func (w *cappedBuffer) Write(p []byte) (int, error) {
	original := len(p)
	remaining := maxOutputBytes - w.n
	if remaining > 0 {
		if len(p) > remaining {
			p = p[:remaining]
		}
		_, _ = w.b.Write(p)
		w.n += len(p)
	}
	return original, nil
}

func main() {
	if len(os.Args) == 2 && os.Args[1] == "healthcheck" {
		if err := runHealthcheck(); err != nil {
			log.Print(err)
			os.Exit(1)
		}
		return
	}
	if len(os.Args) != 1 {
		log.Fatal("usage: labserver [healthcheck]")
	}

	gateToken, err := readSecret(gateTokenPath)
	if err != nil {
		log.Fatalf("load stage credential: %v", err)
	}
	fx, err := newFixture()
	if err != nil {
		log.Fatal(err)
	}
	sessionValue, sessionHash, err := newSessionCapability()
	if err != nil {
		log.Fatalf("create session capability: %v", err)
	}
	app := &application{
		fixture:      fx,
		gateHash:     sha256.Sum256(gateToken),
		sessionValue: sessionValue,
		sessionHash:  sessionHash,
		buildLimiter: make(chan struct{}, 1),
	}

	proxyListener, err := net.Listen("tcp", proxyAddress)
	if err != nil {
		log.Fatalf("listen on module proxy: %v", err)
	}
	go func() {
		server := &http.Server{
			Handler:           fx.proxyHandler(),
			ReadHeaderTimeout: 3 * time.Second,
			ReadTimeout:       10 * time.Second,
			WriteTimeout:      20 * time.Second,
			IdleTimeout:       30 * time.Second,
		}
		if err := server.Serve(proxyListener); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("module proxy: %v", err)
		}
	}()

	mux := http.NewServeMux()
	mux.HandleFunc("GET /{$}", app.handleIndex)
	mux.HandleFunc("GET /health", handleHealth)
	mux.HandleFunc("POST /unlock", app.handleUnlock)
	mux.Handle("GET /lab/metadata", app.requireSession(http.HandlerFunc(app.handleMetadata)))
	mux.Handle("POST /build", app.requireSession(http.HandlerFunc(app.handleBuild)))

	server := &http.Server{
		Addr:              listenAddress,
		Handler:           securityHeaders(mux),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       15 * time.Second,
		WriteTimeout:      70 * time.Second,
		IdleTimeout:       30 * time.Second,
	}
	log.Printf("build service listening on %s; module proxy is loopback-only on %s", listenAddress, proxyAddress)
	log.Fatal(server.ListenAndServe())
}

func runHealthcheck() error {
	client := &http.Client{Timeout: 2 * time.Second}
	response, err := client.Get(healthURL)
	if err != nil {
		return fmt.Errorf("health request: %w", err)
	}
	defer response.Body.Close()
	_, _ = io.Copy(io.Discard, io.LimitReader(response.Body, 4096))
	if response.StatusCode != http.StatusOK {
		return fmt.Errorf("health status: %s", response.Status)
	}
	return nil
}

func readSecret(path string) ([]byte, error) {
	value, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	value = bytes.TrimRight(value, "\r\n")
	if len(value) == 0 {
		return nil, errors.New("credential is empty")
	}
	return value, nil
}

func securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		next.ServeHTTP(w, r)
	})
}

func (app *application) handleIndex(w http.ResponseWriter, r *http.Request) {
	pageName := "lock.html"
	if app.hasSession(r) {
		pageName = "index.html"
	}
	page, err := uiFiles.ReadFile(pageName)
	if err != nil {
		http.Error(w, "UI unavailable", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_, _ = w.Write(page)
}

func handleHealth(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"status":          "ok",
		"runtime_version": runtime.Version(),
		"service":         "build-relay",
	})
}

func newSessionCapability() (string, [sha256.Size]byte, error) {
	random := make([]byte, 32)
	if _, err := rand.Read(random); err != nil {
		return "", [sha256.Size]byte{}, err
	}
	value := base64.RawURLEncoding.EncodeToString(random)
	return value, sha256.Sum256([]byte(value)), nil
}

func (app *application) validStageToken(r *http.Request) bool {
	values := r.Header.Values("X-Stage-Token")
	candidate := ""
	if len(values) > 0 {
		candidate = values[0]
	}
	candidateHash := sha256.Sum256([]byte(candidate))
	oneValue := subtle.ConstantTimeEq(int32(len(values)), 1)
	matchingValue := subtle.ConstantTimeCompare(candidateHash[:], app.gateHash[:])
	return oneValue&matchingValue == 1
}

func (app *application) handleUnlock(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	if !app.validStageToken(r) {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "invalid stage credential"})
		return
	}
	expires := time.Now().Add(sessionMaxAge).UTC()
	app.sessionUntil.Store(expires.Unix())
	http.SetCookie(w, &http.Cookie{
		Name:     sessionCookie,
		Value:    app.sessionValue,
		Path:     "/go/",
		Expires:  expires,
		MaxAge:   int(sessionMaxAge / time.Second),
		HttpOnly: true,
		SameSite: http.SameSiteStrictMode,
	})
	writeJSON(w, http.StatusOK, map[string]bool{"unlocked": true})
}

func (app *application) hasSession(r *http.Request) bool {
	if expires := app.sessionUntil.Load(); expires == 0 || time.Now().Unix() > expires {
		return false
	}
	var candidate string
	count := 0
	for _, cookie := range r.Cookies() {
		if cookie.Name == sessionCookie {
			candidate = cookie.Value
			count++
		}
	}
	candidateHash := sha256.Sum256([]byte(candidate))
	oneValue := subtle.ConstantTimeEq(int32(count), 1)
	matchingValue := subtle.ConstantTimeCompare(candidateHash[:], app.sessionHash[:])
	return oneValue&matchingValue == 1
}

// requireSession checks the browser capability before a protected handler can
// read a body, create a job directory, or launch cmd/go.
func (app *application) requireSession(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !app.hasSession(r) {
			w.Header().Set("Cache-Control", "no-store")
			writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "stage is locked"})
			return
		}
		next.ServeHTTP(w, r)
	})
}

func newFixture() (*fixture, error) {
	toolchainFiles := map[string][]byte{
		"bin/go":         fakeGo,
		"bin/gofmt":      []byte("#!/bin/sh\nexit 0\n"),
		"pkg/tool/dummy": nil,
		"lib/dummy":      nil,
	}
	archive, err := zipModule(moduleRoot, toolchainFiles)
	if err != nil {
		return nil, err
	}
	dependencyArchive, err := zipModule(dependencyRoot, map[string][]byte{
		"go.mod":    dependencyGoMod,
		"future.go": dependencySource,
	})
	if err != nil {
		return nil, err
	}

	toolchainHashFiles := make(map[string][]byte, len(toolchainFiles))
	for name, contents := range toolchainFiles {
		toolchainHashFiles[moduleRoot+"/"+name] = contents
	}
	moduleSum := hash1(toolchainHashFiles)
	goModSum := hash1(map[string][]byte{"go.mod": proxyGoMod})
	zipDigest := sha256.Sum256(archive)
	return &fixture{
		zipBytes:      archive,
		dependencyZip: dependencyArchive,
		moduleSum:     moduleSum,
		goModSum:      goModSum,
		zipSHA256:     hex.EncodeToString(zipDigest[:]),
	}, nil
}

func zipModule(root string, files map[string][]byte) ([]byte, error) {
	var archive bytes.Buffer
	zw := zip.NewWriter(&archive)
	names := make([]string, 0, len(files))
	for name := range files {
		names = append(names, name)
	}
	sort.Strings(names)
	for _, name := range names {
		header := &zip.FileHeader{Name: root + "/" + name, Method: zip.Store}
		header.SetMode(0o644)
		header.SetModTime(time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC))
		writer, err := zw.CreateHeader(header)
		if err != nil {
			return nil, err
		}
		if _, err := writer.Write(files[name]); err != nil {
			return nil, err
		}
	}
	if err := zw.Close(); err != nil {
		return nil, err
	}
	return archive.Bytes(), nil
}

func hash1(files map[string][]byte) string {
	names := make([]string, 0, len(files))
	for name := range files {
		names = append(names, name)
	}
	sort.Strings(names)
	hash := sha256.New()
	for _, name := range names {
		fileHash := sha256.Sum256(files[name])
		fmt.Fprintf(hash, "%x  %s\n", fileHash, name)
	}
	return "h1:" + base64.StdEncoding.EncodeToString(hash.Sum(nil))
}

func (fx *fixture) metadata() attackMetadata {
	return attackMetadata{
		Toolchain:      toolchainName,
		ModuleVersion:  toolchainVer,
		ModuleSum:      fx.moduleSum,
		GoModSum:       fx.goModSum,
		ProxyZipSHA256: fx.zipSHA256,
	}
}

func (app *application) handleMetadata(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	writeJSON(w, http.StatusOK, app.fixture.metadata())
}

func (app *application) handleBuild(w http.ResponseWriter, r *http.Request) {
	// Authentication has already completed in requireSession. In particular,
	// this is the first place a protected request body can be touched.
	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	var request buildRequest
	if err := decoder.Decode(&request); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid JSON request"})
		return
	}
	if err := requireEOF(decoder); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "trailing JSON data"})
		return
	}
	if request.Toolchain != toolchainName || request.ModuleSum != app.fixture.moduleSum || request.GoModSum != app.fixture.goModSum {
		writeJSON(w, http.StatusBadRequest, map[string]string{
			"error": "metadata does not match the selected toolchain proxy",
		})
		return
	}

	select {
	case app.buildLimiter <- struct{}{}:
		defer func() { <-app.buildLimiter }()
	default:
		writeJSON(w, http.StatusTooManyRequests, map[string]string{"error": "build worker is busy"})
		return
	}

	nonceBytes := make([]byte, 16)
	if _, err := rand.Read(nonceBytes); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "nonce generation failed"})
		return
	}
	nonce := hex.EncodeToString(nonceBytes)
	jobDir, err := os.MkdirTemp("/tmp", "go94447-")
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "job setup failed"})
		return
	}
	defer os.RemoveAll(jobDir)

	projectDir := filepath.Join(jobDir, "project")
	for _, dir := range []string{
		projectDir,
		filepath.Join(jobDir, "home"),
		filepath.Join(jobDir, "gopath"),
		filepath.Join(jobDir, "modcache"),
		filepath.Join(jobDir, "gocache"),
	} {
		if err := os.MkdirAll(dir, 0o700); err != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "job directory setup failed"})
			return
		}
	}

	// A dependency requests the higher Go version without using a direct
	// toolchain directive. cmd/go loads the submitted go.sum before resolving
	// the replacement toolchain under stock Go 1.27.1.
	goMod := "module attacker.example/project\n\ngo 1.27.1\n\nrequire " + dependencyMod + " " + dependencyVer + "\n"
	goSum := fmt.Sprintf("%s %s %s\n%s %s/go.mod %s\n",
		toolchainMod, toolchainVer, request.ModuleSum,
		toolchainMod, toolchainVer, request.GoModSum)
	files := map[string]string{
		"go.mod":  goMod,
		"go.sum":  goSum,
		"main.go": "package main\n\nimport _ \"attacker.example/future\"\n\nfunc main() {}\n",
	}
	for name, contents := range files {
		if err := os.WriteFile(filepath.Join(projectDir, name), []byte(contents), 0o600); err != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "project setup failed"})
			return
		}
	}

	markerPath := filepath.Join(jobDir, "execution-marker")
	ctx, cancel := context.WithTimeout(r.Context(), buildTimeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, goBinary, "get", ".")
	cmd.Dir = projectDir
	cmd.Env = []string{
		"PATH=/opt/go/bin:/usr/bin:/bin",
		"HOME=" + filepath.Join(jobDir, "home"),
		"GOENV=off",
		"GO111MODULE=on",
		"GOTOOLCHAIN=auto",
		"GOPROXY=http://" + proxyAddress,
		"GOSUMDB=off",
		"GONOSUMDB=attacker.example",
		"GOPATH=" + filepath.Join(jobDir, "gopath"),
		"GOMODCACHE=" + filepath.Join(jobDir, "modcache"),
		"GOCACHE=" + filepath.Join(jobDir, "gocache"),
		"CGO_ENABLED=0",
		"LAB_NONCE=" + nonce,
		"LAB_MARKER_PATH=" + markerPath,
	}
	before := app.fixture.proxyRequests.Load()
	var output cappedBuffer
	cmd.Stdout = &output
	cmd.Stderr = &output
	runErr := cmd.Run()
	after := app.fixture.proxyRequests.Load()

	response := buildResponse{
		RuntimeVersion:     runtime.Version(),
		RequestedToolchain: request.Toolchain,
		Nonce:              nonce,
		CommandExit:        exitCode(runErr),
		GoOutput:           output.b.String(),
		ProxyRequests:      after - before,
	}
	if runErr != nil {
		response.CommandError = runErr.Error()
	}
	if markerBytes, err := os.ReadFile(markerPath); err == nil {
		response.Marker = strings.TrimRight(string(markerBytes), "\r\n")
		markerLines := strings.Split(response.Marker, "\n")
		expectedProof := "MARKER=GO94447_EXEC:" + nonce
		response.Executed = len(markerLines) == 2 && markerLines[0] == expectedProof && strings.HasPrefix(markerLines[1], "FLAG=") && len(markerLines[1]) > len("FLAG=")
		digest := sha256.Sum256(markerBytes)
		response.MarkerSHA256 = hex.EncodeToString(digest[:])
	}
	w.Header().Set("Cache-Control", "no-store")
	writeJSON(w, http.StatusOK, response)
}

func (fx *fixture) proxyHandler() http.Handler {
	mux := http.NewServeMux()
	base := "/golang.org/toolchain/@v/"
	dependencyBase := "/attacker.example/future/@v/"
	mux.HandleFunc("GET "+base+"list", func(w http.ResponseWriter, _ *http.Request) {
		fx.proxyRequests.Add(1)
		_, _ = io.WriteString(w, toolchainVer+"\n")
	})
	mux.HandleFunc("GET "+base+toolchainVer+".info", func(w http.ResponseWriter, _ *http.Request) {
		fx.proxyRequests.Add(1)
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"Version":"`+toolchainVer+`","Time":"2026-01-01T00:00:00Z"}`)
	})
	mux.HandleFunc("GET "+base+toolchainVer+".mod", func(w http.ResponseWriter, _ *http.Request) {
		fx.proxyRequests.Add(1)
		w.Header().Set("Content-Type", "text/plain")
		_, _ = w.Write(proxyGoMod)
	})
	mux.HandleFunc("GET "+base+toolchainVer+".zip", func(w http.ResponseWriter, _ *http.Request) {
		fx.proxyRequests.Add(1)
		w.Header().Set("Content-Type", "application/zip")
		_, _ = w.Write(fx.zipBytes)
	})
	mux.HandleFunc("GET "+dependencyBase+"list", func(w http.ResponseWriter, _ *http.Request) {
		fx.proxyRequests.Add(1)
		_, _ = io.WriteString(w, dependencyVer+"\n")
	})
	mux.HandleFunc("GET "+dependencyBase+dependencyVer+".info", func(w http.ResponseWriter, _ *http.Request) {
		fx.proxyRequests.Add(1)
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"Version":"`+dependencyVer+`","Time":"2026-01-01T00:00:00Z"}`)
	})
	mux.HandleFunc("GET "+dependencyBase+dependencyVer+".mod", func(w http.ResponseWriter, _ *http.Request) {
		fx.proxyRequests.Add(1)
		w.Header().Set("Content-Type", "text/plain")
		_, _ = w.Write(dependencyGoMod)
	})
	mux.HandleFunc("GET "+dependencyBase+dependencyVer+".zip", func(w http.ResponseWriter, _ *http.Request) {
		fx.proxyRequests.Add(1)
		w.Header().Set("Content-Type", "application/zip")
		_, _ = w.Write(fx.dependencyZip)
	})
	return mux
}

func requireEOF(decoder *json.Decoder) error {
	var extra any
	if err := decoder.Decode(&extra); errors.Is(err, io.EOF) {
		return nil
	} else {
		return err
	}
}

func exitCode(err error) int {
	if err == nil {
		return 0
	}
	var exitErr *exec.ExitError
	if errors.As(err, &exitErr) {
		return exitErr.ExitCode()
	}
	return -1
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}
