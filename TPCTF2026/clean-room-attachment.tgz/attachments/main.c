#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <seccomp.h>

#define MAX_RECORDS 16
#define TEXT_CAP 0xF0
#define BLOB_CAP 0x100
#define MAX_TEXT (16u << 20)
#define MAX_OPS 78
#define MAX_ALLOCS 26
#define MAX_EDITS_PER_SLOT 13
#define MAX_EDIT_TOTAL 0x1B8
#define MAX_IO 0x1000
#define MAX_SHADOW_WRITES 6
#define MAX_ECHO_TOTAL 0x1D8
#define STACK_SPAN 0x800000ULL
#define KIND_TEXT 1
#define KIND_BLOB 2

#define SHADOW_BEGIN 0x7fff8000ULL
#define SHADOW_END 0x10007fff8000ULL

extern char **environ;
extern int __asan_address_is_poisoned(const void *addr);
extern void __asan_unpoison_memory_region(void const volatile *addr, size_t size);

typedef struct Record Record;
struct Record {
    uint32_t kind;
    uint32_t len;
    union {
        char text[TEXT_CAP];
        struct {
            unsigned char *data;
            size_t count;
            unsigned char *self;
            const char *label;
        } blob;
    } u;
};

static const char blob_label[] __attribute__((used)) = "clean-room buffer";

static Record *records[MAX_RECORDS];
static Record *selected;
static uint32_t selected_kind;
static unsigned int op_count;
static unsigned int alloc_count;
static unsigned int edit_counts[MAX_RECORDS];
static size_t edit_bytes;
static uint32_t selected_slot;
static int last_cmd = -1;
static unsigned int cmd_counts[6];
static const unsigned int cmd_caps[6] = {1, 25, 1, 13, 13, 25};
static unsigned int shadow_writes;
static size_t echo_bytes;

static int range_fully_poisoned(uintptr_t p, size_t n) {
    for (size_t i = 0; i < n; i++) {
        if (!__asan_address_is_poisoned((const void *)(p + i))) {
            return 0;
        }
    }
    return 1;
}

static int in_stack_range(uintptr_t p, size_t n) {
    uintptr_t mid = (uintptr_t)environ;
    if (mid < STACK_SPAN) {
        return 0;
    }
    return p >= mid - STACK_SPAN && p + n >= p && p + n <= mid + STACK_SPAN;
}

static int shadow_in_stack(uintptr_t shadow, size_t n) {
    if (shadow < SHADOW_BEGIN || shadow + n < shadow || shadow + n > SHADOW_END) {
        return 0;
    }
    uintptr_t orig = (shadow - SHADOW_BEGIN) << 3;
    return in_stack_range(orig, n << 3);
}

static void install_seccomp(void) {
    static const int allowed[] = {
        SCMP_SYS(fstat), SCMP_SYS(munmap),
        SCMP_SYS(madvise), SCMP_SYS(exit_group),
    };
    scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_KILL_PROCESS);
    if (!ctx) {
        exit(1);
    }
    for (size_t i = 0; i < sizeof(allowed) / sizeof(allowed[0]); i++) {
        if (seccomp_rule_add(ctx, SCMP_ACT_ALLOW, allowed[i], 0) < 0) {
            seccomp_release(ctx);
            exit(1);
        }
    }
    if (seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(mmap), 1,
                         SCMP_A2(SCMP_CMP_MASKED_EQ, PROT_EXEC, 0)) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(openat), 1,
                         SCMP_A2(SCMP_CMP_MASKED_EQ, O_ACCMODE, O_RDONLY)) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 1,
                         SCMP_A0(SCMP_CMP_EQ, 1)) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 1,
                         SCMP_A0(SCMP_CMP_EQ, 2)) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 2,
                         SCMP_A0(SCMP_CMP_EQ, 0),
                         SCMP_A2(SCMP_CMP_LE, 0x1000)) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 2,
                         SCMP_A0(SCMP_CMP_GE, 3),
                         SCMP_A2(SCMP_CMP_LE, 0x1000)) < 0) {
        seccomp_release(ctx);
        exit(1);
    }
    if (seccomp_load(ctx) < 0) {
        seccomp_release(ctx);
        exit(1);
    }
    seccomp_release(ctx);
}

static void quiet_stderr(void) {
    if (getenv("CLEANROOM_DEBUG")) {
        return;
    }
    int fd = open("/dev/null", O_WRONLY);
    if (fd >= 0) {
        dup2(fd, STDERR_FILENO);
        if (fd != STDERR_FILENO) {
            close(fd);
        }
    }
}

static void raw_copy(void *dst, const void *src, size_t n)
    __attribute__((no_sanitize("address")));
static void raw_copy(void *dst, const void *src, size_t n) {
    unsigned char *d = (unsigned char *)dst;
    const unsigned char *s = (const unsigned char *)src;
    for (size_t i = 0; i < n; i++) {
        d[i] = s[i];
    }
}

static int read_line(char *buf, size_t n) {
    if (!fgets(buf, (int)n, stdin)) {
        return -1;
    }
    size_t l = strlen(buf);
    if (l && buf[l - 1] == '\n') {
        buf[--l] = '\0';
    }
    return (int)l;
}

static int read_uint(const char *prompt, uint32_t *out) {
    char line[64];
    printf("%s", prompt);
    fflush(stdout);
    if (read_line(line, sizeof line) < 0) {
        return -1;
    }
    errno = 0;
    char *end = NULL;
    unsigned long v = strtoul(line, &end, 0);
    if (errno || end == line || *end || v > UINT32_MAX) {
        return -1;
    }
    *out = (uint32_t)v;
    return 0;
}

static int read_u64(const char *prompt, uint64_t *out) {
    char line[64];
    printf("%s", prompt);
    fflush(stdout);
    if (read_line(line, sizeof line) < 0) {
        return -1;
    }
    errno = 0;
    char *end = NULL;
    unsigned long long v = strtoull(line, &end, 0);
    if (errno || end == line || *end) {
        return -1;
    }
    *out = (uint64_t)v;
    return 0;
}

static int read_exact(unsigned char *buf, size_t n) {
    size_t off = 0;
    while (off < n) {
        size_t got = fread(buf + off, 1, n - off, stdin);
        if (!got) {
            return -1;
        }
        off += got;
    }
    return 0;
}

static int free_slot(void) {
    for (int i = 0; i < MAX_RECORDS; i++) {
        if (!records[i]) {
            return i;
        }
    }
    return -1;
}

static void create_text(void) {
    if (alloc_count >= MAX_ALLOCS) {
        puts("allocation limit");
        return;
    }
    uint32_t n;
    if (read_uint("length: ", &n) < 0) {
        puts("invalid length");
        return;
    }
    if (n == 0 || n > MAX_TEXT) {
        puts("invalid length");
        return;
    }
    int idx = free_slot();
    if (idx < 0) {
        puts("full");
        return;
    }
    size_t extra = n > TEXT_CAP ? (size_t)n - TEXT_CAP : 0;
    Record *r = calloc(1, sizeof *r + extra);
    if (!r) {
        puts("out of memory");
        return;
    }
    r->kind = KIND_TEXT;
    r->len = n;
    records[idx] = r;
    alloc_count++;
    printf("created text at %d\n", idx);
}

static void create_blob(void) {
    if (alloc_count >= MAX_ALLOCS) {
        puts("allocation limit");
        return;
    }
    int idx = free_slot();
    if (idx < 0) {
        puts("full");
        return;
    }
    Record *r = calloc(1, sizeof *r);
    if (!r) {
        puts("out of memory");
        return;
    }
    unsigned char *data = malloc(BLOB_CAP);
    if (!data) {
        free(r);
        puts("out of memory");
        return;
    }
    memset(data, 0, BLOB_CAP);
    r->kind = KIND_BLOB;
    r->len = 0x18;
    r->u.blob.data = data;
    r->u.blob.count = BLOB_CAP;
    r->u.blob.self = (unsigned char *)r;
    r->u.blob.label = blob_label;
    records[idx] = r;
    alloc_count++;
    printf("created buffer at %d\n", idx);
}

static void select_record(void) {
    uint32_t idx;
    if (read_uint("slot: ", &idx) < 0) {
        puts("invalid slot");
        return;
    }
    if (idx >= MAX_RECORDS || !records[idx]) {
        puts("invalid slot");
        return;
    }
    selected = records[idx];
    selected_kind = selected->kind;
    selected_slot = idx;
    printf("selected %u\n", idx);
    if (selected_kind == KIND_BLOB) {
        uint64_t addr;
        if (read_u64("address (0 keeps current): ", &addr) < 0) {
            puts("invalid address");
            return;
        }
        if (addr != 0) {
            uint32_t n;
            if (read_uint("length: ", &n) < 0 || n == 0 || n > MAX_IO) {
                puts("invalid length");
                return;
            }
            uintptr_t d = (uintptr_t)addr;
            uintptr_t rec = (uintptr_t)selected;
            int own_record = d >= rec && d + n <= rec + sizeof(*selected);
            int asan_shadow = d >= SHADOW_BEGIN && d + n <= SHADOW_END &&
                              shadow_in_stack(d, n);
            int asan_poisoned = 0;
            if (!own_record && !asan_shadow && in_stack_range(d, n)) {
                asan_poisoned = range_fully_poisoned(d, n);
            }
            if (!own_record && !asan_shadow && !asan_poisoned) {
                puts("target protected");
                return;
            }
            if (!own_record && !asan_poisoned && n > 8) {
                puts("target limited");
                return;
            }
            selected->u.blob.data = (unsigned char *)d;
            selected->u.blob.count = n;
        }
    }
}

static void edit_selected(void) {
    if (!selected) {
        puts("nothing selected");
        return;
    }
    if (selected_slot >= MAX_RECORDS ||
        ++edit_counts[selected_slot] > MAX_EDITS_PER_SLOT) {
        puts("edit limit");
        return;
    }
    unsigned char view[MAX_IO];
    size_t view_n = 0;
    const unsigned char *view_src = NULL;
    if (selected_kind == KIND_TEXT) {
        uint32_t l = selected->len;
        if (l > TEXT_CAP) {
            l = TEXT_CAP;
        }
        view_n = l;
        view_src = (const unsigned char *)selected->u.text;
        printf("text[%u]: ", (unsigned)view_n);
    } else if (selected_kind == KIND_BLOB) {
        if (selected->u.blob.count > MAX_IO) {
            puts("invalid view");
            return;
        }
        view_n = selected->u.blob.count;
        view_src = selected->u.blob.data;
        printf("blob[%zu]: ", view_n);
    } else {
        puts("unsupported record");
        return;
    }
    if (echo_bytes + view_n > MAX_ECHO_TOTAL) {
        puts("read budget");
        return;
    }
    echo_bytes += view_n;
    raw_copy(view, view_src, view_n);
    fflush(stdout);
    fwrite(view, 1, view_n, stdout);
    putchar('\n');
    uint32_t n;
    if (read_uint("length: ", &n) < 0) {
        puts("invalid length");
        return;
    }
    if (n == 0 || n > MAX_IO) {
        puts("invalid length");
        return;
    }
    if (selected_kind == KIND_TEXT) {
        if (n > TEXT_CAP) {
            puts("invalid length");
            return;
        }
    } else if (selected_kind == KIND_BLOB) {
        if (n > selected->u.blob.count) {
            puts("invalid length");
            return;
        }
    } else {
        puts("unsupported record");
        return;
    }
    if (edit_bytes + n > MAX_EDIT_TOTAL) {
        puts("byte budget");
        return;
    }
    unsigned char buf[MAX_IO];
    printf("data: ");
    fflush(stdout);
    if (read_exact(buf, n) < 0) {
        puts("short data");
        return;
    }
    if (selected_kind == KIND_TEXT) {
        memcpy(selected->u.text, buf, n);
        edit_bytes += n;
    } else {
        unsigned char *dst = selected->u.blob.data;
        uintptr_t d = (uintptr_t)dst;
        uintptr_t rec = (uintptr_t)selected;
        int own_record = d >= rec && d + n <= rec + sizeof(*selected);
        int asan_shadow = d >= SHADOW_BEGIN && d + n <= SHADOW_END &&
                          shadow_in_stack(d, n);
        int asan_poisoned = 0;
        if (!own_record && !asan_shadow && in_stack_range(d, n)) {
            asan_poisoned = range_fully_poisoned(d, n);
        }
        if (!own_record && !asan_shadow && !asan_poisoned) {
            puts("write protected");
            return;
        }
        if (!own_record && !asan_poisoned && n > 8) {
            puts("write limited");
            return;
        }
        if (asan_shadow) {
            if (++shadow_writes > MAX_SHADOW_WRITES) {
                puts("shadow limit");
                return;
            }
        }
        if (asan_poisoned) {
            __asan_unpoison_memory_region(dst, n);
        }
        raw_copy(dst, buf, n);
        edit_bytes += n;
    }
    puts("ok");
}

static void delete_record(void) {
    uint32_t idx;
    if (read_uint("slot: ", &idx) < 0) {
        puts("invalid slot");
        return;
    }
    if (idx >= MAX_RECORDS || !records[idx]) {
        puts("invalid slot");
        return;
    }
    if (records[idx]->kind == KIND_BLOB) {
        free(records[idx]->u.blob.data);
    }
    free(records[idx]);
    records[idx] = NULL;
    puts("deleted");
}

int main(void) {
    quiet_stderr();
    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(120);
    install_seccomp();

    char line[64];
    puts("== clean-room ==");
    for (;;) {
        puts("1 create text\n"
             "2 create buffer\n"
             "3 select\n"
             "4 edit\n"
             "5 delete\n"
             "0 quit");
        printf("> ");
        fflush(stdout);
        if (read_line(line, sizeof line) < 0) {
            break;
        }
        op_count++;
        if (op_count > MAX_OPS) {
            puts("operation limit");
            return 0;
        }
        int cmd = atoi(line);
        if (cmd != 0 && cmd == last_cmd) {
            puts("command sequence rejected");
            return 0;
        }
        last_cmd = cmd;
        if (cmd >= 0 && cmd < 6 && ++cmd_counts[cmd] > cmd_caps[cmd]) {
            puts("command quota");
            return 0;
        }
        switch (cmd) {
        case 1:
            create_text();
            break;
        case 2:
            create_blob();
            break;
        case 3:
            select_record();
            break;
        case 4:
            edit_selected();
            break;
        case 5:
            delete_record();
            break;
        case 0:
            return 0;
        default:
            puts("unknown command");
            break;
        }
    }
    return 0;
}
