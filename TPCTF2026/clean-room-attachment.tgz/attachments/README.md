# clean-room

## The service

`clean-room` is a small record manager. It stores text records and buffer
records in a table and exposes a line-based menu over TCP:

```
1 create text
2 create buffer
3 select
4 edit
5 delete
0 quit
```

A text record has a length and an inline text buffer. A buffer record has a
separate data allocation, a count, a self pointer, and a static label.
`select` chooses a record for `edit`. When the selected record is a buffer,
`select` also asks for an optional target address: `0` keeps the current
descriptor, a non-zero address retargets the buffer.

`edit` first echoes the current text or buffer view, then asks for new data;
the same operation is therefore both the read and write path.

Buffer writes are restricted:

* own-record writes are allowed in full;
* ASan shadow writes are allowed only for stack shadow, capped at 8 bytes;
* a poisoned destination is accepted only when **the entire range** is
  poisoned and the range is on the stack; the service unpoisons it first;
* GOT, BSS, libc, and non-stack ASan metadata destinations are rejected.

## Budgets

Per connection:

* at most **78 menu commands**;
* at most **26 allocations**;
* at most **13 edits per slot**;
* at most **0x1B8 bytes** written through `edit` in total;
* at most **0x1D8 bytes** echoed back through `edit` in total;
* at most **6 ASan shadow writes**;
* the same menu command may not be used twice in a row;
* per-command quotas: `create text` 25, `create buffer` 1, `select` 13,
  `edit` 13, `delete` 25.

Exceeding any budget ends the session.

## Sanitizers and sandbox

The binary is built with **AddressSanitizer**, **UndefinedBehaviorSanitizer**,
**`_FORTIFY_SOURCE=3`**, stack protector (`-fstack-protector-all`), full RELRO, and a **seccomp allowlist**. Sanitizer findings and
disallowed syscalls terminate the process. The service redirects sanitizer
diagnostics to `/dev/null`, so a rejected request simply loses the connection.

The seccomp filter allows only:

```
fstat, munmap, madvise, exit_group
read from fd 0 or fd >= 3, count <= 0x1000
mmap without PROT_EXEC
openat with O_RDONLY
write to fd 1 or 2
```

Everything else is killed, including `execve`, `execveat`, `fork`, `vfork`,
`clone`, `clone3`, `socket`, `ptrace`, `mprotect`, `close`, and
`rt_sigaction`. Getting a shell is not an option, and neither is an RWX/JIT
path; the service can only perform the file/syscall operations needed by the
intended `open` / `read` / `write` path.

The answer is the file `/answers/flag` at run time. There is no dedicated
flag-reading menu command.

## Environment

* Debian **13** (`debian:13-slim`,
  `sha256:913f6706df59a68922d1dd08f78c2476560a8d367897200a6005b00e5f67c2d5`).
* Built with Debian's **clang 19** using ASan/UBSan, `_FORTIFY_SOURCE=3`,
  `-fstack-protector-all`, full RELRO, and a statically linked libseccomp
  filter.
* The sanitizer runtime is embedded in the binary. `libc.so.6` from the
  runtime image is included for local matching.

## Files

* `main.c` — the service source, identical to what is deployed.
* `challenge` — the deployed binary.
* `libc.so.6` — the glibc the service runs against.
