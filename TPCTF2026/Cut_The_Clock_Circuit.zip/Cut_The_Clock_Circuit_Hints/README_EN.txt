CUT THE CLOCK — circuit-analysis supplement

IMPORTANT: This is a runnable REFERENCE circuit for understanding the logic,
not a per-team dynamic instance. The actual cut schedule may depend on the
instance ID, so a sequence found in this reference may not work for your
competition instance. This package does not contain a flag, encrypted
payload, release tool, or a replacement for the platform's dynamic flow.

Open bomb_reference.circ with Logisim-evolution 3.8.0; no plugins needed.
Disable automatic ticks. CLK is a manual input and CUTS is ordered W5..W1.
A 0 means intact; a 1 means cut. With CLK=0, CUTS=00000, assert RESET=1,
then return RESET=0. You should see T=0, STAGE=0, SAFE=0, BOOM=0.

A cycle is one CLK 0->1->0 sequence. Change CUTS only while CLK=0.
The displayed T is the count BEFORE the next rising edge. Cutting at T=12
is sampled on the rising edge that advances T to 13.

Each wire may be cut only once during a run. Reconnecting a wire or changing
multiple wires on a single rising edge causes failure; use RESET to retry.
The objective for this supplemental exercise is to understand how STAGE
advances to SAFE=1 with BOOM=0. Outputs A and B are optional trace markers.


